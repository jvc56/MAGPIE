#!/usr/bin/env bash
set -euo pipefail
repo=/Users/olaugh/sources/magpie-pat-simcmp
dir=/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40
while [[ ! -f "$dir/select941_status.txt" ]]; do sleep 10; done
cd "$repo"
ranks=1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,49,89
env PCD_ADAPTIVE=1 PCD_POOL=120 PCD_EXCHANGE_QUOTA=5 PCD_EXCHANGE_MARGIN=35 PCD_IN="$dir/new1217.cgp" PCD_OUT="$dir/new1217_all25_p16.csv" PCD_VALIDATE_RANKS="$ranks" PCD_REF_MS=600000 PCD_PLIES=16 PCD_SEED=2026092972 PCD_DEADLINE=1790719259 "$dir/magpie_test_reference" patcanddiversity > "$dir/new1217_all25_p16.log" 2>&1
printf 'finished=%s failed=0\n' "$(date -u +%FT%TZ)" > "$dir/new1217_status.txt"
