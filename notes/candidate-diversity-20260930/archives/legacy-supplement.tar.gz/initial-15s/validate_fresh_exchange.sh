#!/usr/bin/env bash
set -euo pipefail
repo=/Users/olaugh/sources/magpie-pat-simcmp
dir=/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40
cd "$repo"
ranks=1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,53,63,72,76,83,91,105
for plies in 6 16; do
 budget=300000
 if [[ "$plies" -eq 16 ]]; then budget=600000; fi
 env PCD_ADAPTIVE=1 PCD_TILE_ONLY=1 PCD_POOL=120 PCD_EXCHANGE_QUOTA=5 PCD_EXCHANGE_MARGIN=35 PCD_IN="$dir/tile_followup/validate106.cgp" PCD_OUT="$dir/tile_followup/validate106_p${plies}.csv" PCD_VALIDATE_RANKS="$ranks" PCD_REF_MS="$budget" PCD_PLIES="$plies" PCD_SEED=$((2026100300+plies)) PCD_DEADLINE=1790719139 "$dir/magpie_test_fixed" patcanddiversity > "$dir/tile_followup/validate106_p${plies}.log" 2>&1 &
 pid=$!
 printf '%s\n' "$pid" > "$dir/tile_followup/validation_pid.txt"
 wait "$pid"
done
printf 'finished=%s failed=0\n' "$(date -u +%FT%TZ)" > "$dir/tile_followup/validation_status.txt"
