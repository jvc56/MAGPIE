#!/usr/bin/env bash
set -euo pipefail
repo=/Users/olaugh/sources/magpie-pat-simcmp
dir=/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40
cd "$repo"
pids=()
for worker in 0 1; do
 env PCD_ADAPTIVE=1 PCD_EXPLORE=1 PCD_POOL=120 PCD_EXCHANGE_QUOTA=5 PCD_EXCHANGE_MARGIN=35 PCD_CONDITION_DRAWS=1 PCD_CONDITION_ONLY=1 PCD_IN="$dir/conditioned_positions.cgp" PCD_OUT="$dir/c${worker}.csv" PCD_WORKER="$worker" PCD_NUM_WORKERS=2 PCD_MS=15000 PCD_PLIES=4 PCD_DEADLINE=1790719259 "$dir/magpie_test_conditioned" patcanddiversity > "$dir/c${worker}.log" 2>&1 &
 pids+=("$!")
done
printf '%s\n' "${pids[@]}" > "$dir/conditioned_pids.txt"
failed=0
for pid in "${pids[@]}"; do
 if ! wait "$pid"; then failed=1; fi
done
printf 'finished=%s failed=%s\n' "$(date -u +%FT%TZ)" "$failed" > "$dir/conditioned_status.txt"
exit "$failed"
