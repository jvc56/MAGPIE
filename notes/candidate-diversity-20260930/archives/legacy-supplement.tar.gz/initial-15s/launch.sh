#!/usr/bin/env bash
set -euo pipefail
repo=/Users/olaugh/sources/magpie-pat-simcmp
dir=/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40
cd "$repo"
rm -f settings.txt
pids=()
for worker in {0..7}; do
 env PCD_ADAPTIVE=1 PCD_EXPLORE=1 PCD_POOL=120 PCD_EXCHANGE_QUOTA=5 PCD_EXCHANGE_MARGIN=35 PCD_IN="$dir/positions.cgp" PCD_OUT="$dir/w${worker}.csv" PCD_WORKER="$worker" PCD_NUM_WORKERS=8 PCD_MS=15000 PCD_REF_MS=60000 PCD_PLIES=4 PCD_DEADLINE=1790719259 "$dir/magpie_test_extended" patcanddiversity > "$dir/w${worker}.log" 2>&1 &
 pids+=("$!")
done
printf '%s\n' "${pids[@]}" > "$dir/pids.txt"
failed=0
for pid in "${pids[@]}"; do
 if ! wait "$pid"; then failed=1; fi
done
printf 'finished=%s failed=%s\n' "$(date -u +%FT%TZ)" "$failed" > "$dir/status.txt"
exit "$failed"
