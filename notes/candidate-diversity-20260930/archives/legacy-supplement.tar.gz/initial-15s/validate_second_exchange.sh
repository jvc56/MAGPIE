#!/usr/bin/env bash
set -euo pipefail
repo=/Users/olaugh/sources/magpie-pat-simcmp
dir=/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40
cd "$repo"
ranks=1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,33,62,76,112,116,117
extra=33,62,76,112,116,117
env PCD_ADAPTIVE=1 PCD_POOL=120 PCD_EXCHANGE_QUOTA=5 PCD_EXCHANGE_MARGIN=35 PCD_IN="$dir/tile_followup/validate6007.cgp" PCD_OUT="$dir/tile_followup/validate6007_p16.csv" PCD_VALIDATE_RANKS="$ranks" PCD_REF_MS=300000 PCD_PLIES=16 PCD_SEED=2026100500 PCD_DEADLINE=1790719139 "$dir/magpie_test_fixed" patcanddiversity > "$dir/tile_followup/validate6007_p16.log" 2>&1 &
pid=$!
printf '%s\n' "$pid" > "$dir/tile_followup/validation6007_pid.txt"
wait "$pid"
env PCD_ADAPTIVE=1 PCD_ADMIT_RANKS="$extra" PCD_SELECTION_NO_CUTOFF=1 PCD_POOL=120 PCD_EXCHANGE_QUOTA=5 PCD_EXCHANGE_MARGIN=35 PCD_IN="$dir/tile_followup/validate6007.cgp" PCD_OUT="$dir/tile_followup/admission6007_p16.csv" PCD_MS=15000 PCD_PLIES=16 PCD_SEED=2026100600 PCD_DEADLINE=1790719139 "$dir/magpie_test_admission" patcanddiversity > "$dir/tile_followup/admission6007_p16.log" 2>&1 &
pid=$!
printf '%s\n' "$pid" > "$dir/tile_followup/validation6007_pid.txt"
wait "$pid"
printf 'finished=%s failed=0\n' "$(date -u +%FT%TZ)" > "$dir/tile_followup/validation6007_status.txt"
