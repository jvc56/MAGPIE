#!/usr/bin/env bash
set -euo pipefail
repo=/Users/olaugh/sources/magpie-pat-simcmp
dir=/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40
while [[ ! -f "$dir/tile_followup/validation_status.txt" ]]; do sleep 10; done
if ! rg -q 'failed=0' "$dir/tile_followup/validation_status.txt"; then exit 1; fi
cd "$repo"
ranks=53,63,72,76,83,91,105
for plies in 6 16; do
 env PCD_ADAPTIVE=1 PCD_ADMIT_RANKS="$ranks" PCD_SELECTION_NO_CUTOFF=1 PCD_POOL=120 PCD_EXCHANGE_QUOTA=5 PCD_EXCHANGE_MARGIN=35 PCD_IN="$dir/tile_followup/validate106.cgp" PCD_OUT="$dir/tile_followup/admission106_p${plies}.csv" PCD_MS=15000 PCD_PLIES="$plies" PCD_SEED=$((2026100400+plies)) PCD_DEADLINE=1790719139 "$dir/magpie_test_admission" patcanddiversity > "$dir/tile_followup/admission106_p${plies}.log" 2>&1 &
 pid=$!
 printf '%s\n' "$pid" > "$dir/tile_followup/admission_pid.txt"
 wait "$pid"
done
printf 'finished=%s failed=0\n' "$(date -u +%FT%TZ)" > "$dir/tile_followup/admission_status.txt"
