#!/usr/bin/env bash
set -euo pipefail
repo=/Users/olaugh/sources/magpie-pat-simcmp
dir=/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40
while [[ ! -f "$dir/status.txt" ]]; do sleep 10; done
if ! rg -q 'failed=0' "$dir/status.txt"; then exit 1; fi
if [[ $(date +%s) -ge 1790719139 ]]; then exit 0; fi
cd "$repo"
pids=()
for worker in 0 1 2 3; do
 env PCD_ADAPTIVE=1 PCD_EXPLORE=1 PCD_WIDTH_ONLY=1 PCD_WIDTH_REFERENCE=1 PCD_CONDITION_DRAWS=1 PCD_POOL=120 PCD_EXCHANGE_QUOTA=5 PCD_EXCHANGE_MARGIN=35 PCD_IN="$dir/depth_positions.cgp" PCD_OUT="$dir/d${worker}.csv" PCD_WORKER="$worker" PCD_NUM_WORKERS=4 PCD_MS=15000 PCD_REF_MS=60000 PCD_PLIES=6 PCD_DEADLINE=1790719139 "$dir/magpie_test_fixed" patcanddiversity > "$dir/d${worker}.log" 2>&1 &
 pids+=("$!")
done
printf '%s\n' "${pids[@]}" > "$dir/depth_pids.txt"
failed=0
for pid in "${pids[@]}"; do
 if ! wait "$pid"; then failed=1; fi
done
printf 'finished=%s failed=%s\n' "$(date -u +%FT%TZ)" "$failed" > "$dir/depth_status.txt"
exit "$failed"
