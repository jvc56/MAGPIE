#!/usr/bin/env bash
set -euo pipefail
repo=/Users/olaugh/sources/magpie-pat-simcmp
dir=/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40
while [[ ! -f "$dir/admission_status.txt" ]]; do sleep 10; done
if ! rg -q 'failed=0' "$dir/admission_status.txt"; then exit 1; fi
cd "$repo"
for spec in 1124:32 2151:121 1542:58; do
 pos=${spec%:*}
 rank=${spec#*:}
 ranks=1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,$rank
 if [[ $(date +%s) -ge 1790718899 ]]; then break; fi
 env PCD_ADAPTIVE=1 PCD_POOL=120 PCD_EXCHANGE_QUOTA=5 PCD_EXCHANGE_MARGIN=35 PCD_IN="$dir/exchange${pos}.cgp" PCD_OUT="$dir/exchange${pos}_all25_p16.csv" PCD_VALIDATE_RANKS="$ranks" PCD_REF_MS=180000 PCD_PLIES=16 PCD_SEED=$((2026093100+pos)) PCD_DEADLINE=1790719139 "$dir/magpie_test_fixed" patcanddiversity > "$dir/exchange${pos}_all25_p16.log" 2>&1 &
 pid=$!
 printf '%s\n' "$pid" > "$dir/exchange_validation_pid.txt"
 wait "$pid"
done
printf 'finished=%s failed=0\n' "$(date -u +%FT%TZ)" > "$dir/exchange_validation_status.txt"
