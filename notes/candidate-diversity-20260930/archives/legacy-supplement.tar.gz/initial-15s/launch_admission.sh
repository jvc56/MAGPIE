#!/usr/bin/env bash
set -euo pipefail
repo=/Users/olaugh/sources/magpie-pat-simcmp
dir=/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40
while [[ ! -f "$dir/conditioned_recovery_status.txt" ]]; do sleep 10; done
if ! rg -q 'failed=0' "$dir/conditioned_recovery_status.txt"; then exit 1; fi
cd "$repo"
for spec in 493:26 580:26 1100:57 2241:34 1755:120 1217:49,89; do
 pos=${spec%:*}
 ranks=${spec#*:}
 env PCD_ADAPTIVE=1 PCD_ADMIT_RANKS="$ranks" PCD_SELECTION_NO_CUTOFF=1 PCD_POOL=120 PCD_EXCHANGE_QUOTA=5 PCD_EXCHANGE_MARGIN=35 PCD_IN="$dir/new${pos}.cgp" PCD_OUT="$dir/admission${pos}_p16.csv" PCD_MS=15000 PCD_PLIES=16 PCD_SEED=$((2026093000+pos)) PCD_DEADLINE=1790719139 "$dir/magpie_test_admission" patcanddiversity > "$dir/admission${pos}_p16.log" 2>&1 &
 pid=$!
 printf '%s\n' "$pid" > "$dir/admission_pid.txt"
 wait "$pid"
done
printf 'finished=%s failed=0\n' "$(date -u +%FT%TZ)" > "$dir/admission_status.txt"
