#!/usr/bin/env bash
set -euo pipefail
repo=/Users/olaugh/sources/magpie-pat-simcmp
dir=/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40
sleep 45
cd "$repo"
env PCD_ADAPTIVE=1 PCD_POOL=120 PCD_EXCHANGE_QUOTA=5 PCD_EXCHANGE_MARGIN=35 PCD_IN="$dir/old941.cgp" PCD_OUT="$dir/alternatives941_p16.csv" PCD_VALIDATE_RANKS=3,32,33,55 PCD_REF_MS=300000 PCD_PLIES=16 PCD_SEED=2026092970 PCD_DEADLINE=1790719259 "$dir/magpie_test_reference" patcanddiversity > "$dir/alternatives941_p16.log" 2>&1
printf 'finished=%s failed=0\n' "$(date -u +%FT%TZ)" > "$dir/alternatives941_status.txt"
