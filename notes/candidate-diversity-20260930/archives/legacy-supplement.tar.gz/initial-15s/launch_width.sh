#!/usr/bin/env bash
set -euo pipefail
repo=/Users/olaugh/sources/magpie-pat-simcmp
dir=/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40
while [[ ! -f "$dir/conditioned_status.txt" ]]; do sleep 10; done
if ! rg -q 'failed=0' "$dir/conditioned_status.txt"; then exit 1; fi
if [[ $(date +%s) -ge 1790719259 ]]; then exit 0; fi
cd "$repo"
pids=()
for worker in 0 1; do
 env PCD_ADAPTIVE=1 PCD_EXPLORE=1 PCD_WIDTH_ONLY=1 PCD_CONDITION_DRAWS=1 PCD_POOL=120 PCD_EXCHANGE_QUOTA=5 PCD_EXCHANGE_MARGIN=35 PCD_IN="$dir/conditioned_positions.cgp" PCD_OUT="$dir/v${worker}.csv" PCD_WORKER="$worker" PCD_NUM_WORKERS=2 PCD_MS=15000 PCD_PLIES=4 PCD_DEADLINE=1790719259 "$dir/magpie_test_width" patcanddiversity > "$dir/v${worker}.log" 2>&1 &
 pids+=("$!")
done
printf '%s\n' "${pids[@]}" > "$dir/width_pids.txt"
failed=0
for pid in "${pids[@]}"; do
 if ! wait "$pid"; then failed=1; fi
done
printf 'finished=%s failed=%s\n' "$(date -u +%FT%TZ)" "$failed" > "$dir/width_status.txt"
exit "$failed"
