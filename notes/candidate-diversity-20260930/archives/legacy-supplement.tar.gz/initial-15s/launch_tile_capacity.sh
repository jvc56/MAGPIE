#!/usr/bin/env bash
set -euo pipefail
repo=/Users/olaugh/sources/magpie-pat-simcmp
dir=/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40
while true; do
 alive=0
 while read -r pid; do
  if kill -0 "$pid" 2>/dev/null; then alive=$((alive+1)); fi
 done < "$dir/pids.txt"
 if [[ "$alive" -le 2 ]]; then break; fi
 sleep 10
done
if [[ $(date +%s) -ge 1790719139 ]]; then exit 0; fi
cd "$repo"
pids=()
for worker in 0 1; do
 env PCD_ADAPTIVE=1 PCD_EXPLORE=1 PCD_TILE_ONLY=1 PCD_TILE_REFERENCE=1 PCD_SELECTION_NO_CUTOFF=1 PCD_POOL=120 PCD_EXCHANGE_QUOTA=5 PCD_EXCHANGE_MARGIN=35 PCD_SEED=2026092983 PCD_IN="$dir/tile_followup/positions.cgp" PCD_OUT="$dir/tile_followup/w${worker}.csv" PCD_WORKER="$worker" PCD_NUM_WORKERS=2 PCD_MS=15000 PCD_REF_MS=60000 PCD_PLIES=4 PCD_DEADLINE=1790719139 "$dir/magpie_test_tile_v3" patcanddiversity > "$dir/tile_followup/w${worker}.log" 2>&1 &
 pids+=("$!")
done
printf '%s\n' "${pids[@]}" > "$dir/tile_followup/pids.txt"
failed=0
for pid in "${pids[@]}"; do
 if ! wait "$pid"; then failed=1; fi
done
printf 'finished=%s failed=%s\n' "$(date -u +%FT%TZ)" "$failed" > "$dir/tile_followup/status.txt"
exit "$failed"
