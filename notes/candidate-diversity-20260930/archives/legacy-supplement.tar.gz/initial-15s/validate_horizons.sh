#!/usr/bin/env bash
set -euo pipefail
repo=/Users/olaugh/sources/magpie-pat-simcmp
dir=/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40
cd "$repo"
for pos in 941 193 624; do
 case "$pos" in
  941) ranks=32,6 ;;
  193) ranks=20,2 ;;
  624) ranks=25,6 ;;
 esac
 for plies in 6 16; do
  seed=$((2026092930 + plies))
  env PCD_ADAPTIVE=1 PCD_POOL=120 PCD_EXCHANGE_QUOTA=5 PCD_EXCHANGE_MARGIN=35 PCD_IN="$dir/old${pos}.cgp" PCD_OUT="$dir/horizon${pos}_p${plies}.csv" PCD_VALIDATE_RANKS="$ranks" PCD_REF_MS=120000 PCD_PLIES="$plies" PCD_SEED="$seed" PCD_DEADLINE=1790719259 "$dir/magpie_test_validation" patcanddiversity > "$dir/horizon${pos}_p${plies}.log" 2>&1
 done
done
printf 'finished=%s failed=0\n' "$(date -u +%FT%TZ)" > "$dir/horizon_status.txt"
