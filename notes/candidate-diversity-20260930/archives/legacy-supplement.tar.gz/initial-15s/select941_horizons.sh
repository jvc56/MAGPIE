#!/usr/bin/env bash
set -euo pipefail
repo=/Users/olaugh/sources/magpie-pat-simcmp
dir=/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40
while [[ ! -f "$dir/alternatives941_status.txt" ]]; do sleep 10; done
cd "$repo"
for plies in 4 6 16; do
 env PCD_ADAPTIVE=1 PCD_EXPLORE=1 PCD_WIDTH_ONLY=1 PCD_CONDITION_DRAWS=1 PCD_POOL=120 PCD_EXCHANGE_QUOTA=5 PCD_EXCHANGE_MARGIN=35 PCD_IN="$dir/old941.cgp" PCD_OUT="$dir/select941_p${plies}.csv" PCD_MS=15000 PCD_PLIES="$plies" PCD_SEED=2026092971 PCD_DEADLINE=1790719259 "$dir/magpie_test_depth" patcanddiversity > "$dir/select941_p${plies}.log" 2>&1
 done
printf 'finished=%s failed=0\n' "$(date -u +%FT%TZ)" > "$dir/select941_status.txt"
