#!/usr/bin/env bash
set -euo pipefail
repo=/Users/olaugh/sources/magpie-pat-simcmp
dir=/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40
while true; do
 alive=0
 while read -r pid; do
  if kill -0 "$pid" 2>/dev/null; then alive=$((alive+1)); fi
 done < "$dir/pids.txt"
 if [[ "$alive" -le 1 ]]; then break; fi
 sleep 10
done
if [[ $(date +%s) -ge 1790719139 ]]; then exit 0; fi
cd "$repo"
env PCD_ADAPTIVE=1 PCD_EXPLORE=1 PCD_CONDITION_ONLY=1 PCD_CONDITION_DRAWS=1 PCD_POOL=120 PCD_EXCHANGE_QUOTA=5 PCD_EXCHANGE_MARGIN=35 PCD_IN="$dir/conditioned_missing.cgp" PCD_OUT="$dir/c0.csv" PCD_MS=15000 PCD_PLIES=4 PCD_DEADLINE=1790719139 "$dir/magpie_test_fixed" patcanddiversity > "$dir/conditioned_recovery.log" 2>&1 &
pid=$!
printf '%s\n' "$pid" > "$dir/conditioned_recovery_pid.txt"
failed=0
if ! wait "$pid"; then failed=1; fi
printf 'finished=%s failed=%s\n' "$(date -u +%FT%TZ)" "$failed" > "$dir/conditioned_recovery_status.txt"
exit "$failed"
