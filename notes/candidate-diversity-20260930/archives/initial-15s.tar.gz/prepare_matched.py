import csv,json,hashlib,sys
from pathlib import Path
D=Path(sys.argv[1]);data={}
for f in D.glob('w[0-7].csv'):
 for r in csv.DictReader(f.open()):
  if r.get('arm') in ('setup_wide','combined') and r.get('candidates'):data[(int(r['pos']),r['arm'])]=int(r['candidates'])
positions=[int(l.split(',',1)[0]) for l in (D/'conditioned_positions.cgp').read_text().splitlines()]
with (D/'matched_counts.csv').open('w') as f:
 f.write('pos,setup_count,combined_count\n')
 for p in positions:f.write(f"{p},{data[p,'setup_wide']},{data[p,'combined']}\n")
j={'positions':128,'sample':'same preselected96nonopening +32opening secondary sample','arms':['static_setup_count','static_combined_count'],'width':'exactly the corresponding main-policy candidate count per position','selection_ms':15000,'cutoff':'disabled','plies':4,'rollout':'static noPAT','reference':'main independent four-ply wholepool reference','start':'after six-ply study, reusing four freed worker slots','workers':4,'binary_sha256':hashlib.sha256((D/'magpie_test_matched').read_bytes()).hexdigest()}
(D/'matched_manifest.json').write_text(json.dumps(j,indent=2)+'\n')
