import csv,json,math,sys
from pathlib import Path
D=Path(sys.argv[1]);s=json.loads((D/'summary.json').read_text());expected={int(l.split(',',1)[0]) for l in (D/'positions.cgp').read_text().splitlines()};assert len(expected)==320;meta={int(r['pos']) for r in csv.DictReader((D/'positions.meta.csv').open())};assert len(meta)==256 and meta=={p for p in expected if p<6000}
features={}
for r in csv.DictReader((D/'candidate_features.csv').open()):features.setdefault(int(r['pos']),{})[int(r['pool_index'])]=r
assert set(features)==expected
rows={};complete_groups=0
for f in sorted(D.glob('w[0-7].csv')):
 for r in csv.DictReader(f.open()):
  if None in r or any(r.get(k) in (None,'') for k in ['pos','arm','static_rank','candidates','sim_wp','sim_eq','chosen']):continue
  p=int(r['pos']);k=int(r['static_rank']);assert p in expected;assert r['move']==features[p][k]['move'];assert int(r['global_static_rank'])==int(features[p][k]['global_static_rank']);assert abs(float(r['static_eq'])-float(features[p][k]['static_eq']))<1e-5
  assert math.isfinite(float(r['sim_eq'])) and 0<=float(r['sim_wp'])<=1
  rows.setdefault((p,r['arm']),{})[k]=r
for (p,a),rr in rows.items():
 if len(rr)!=int(next(iter(rr.values()))['candidates']):continue
 complete_groups+=1;assert sum(int(r['chosen']) for r in rr.values())==1
 if a=='reference':assert set(rr)==set(features[p])
 if a in ['static25','threat_wide','setup_wide','signals','exchange','combined']:assert set(range(1,26))<=set(rr)
 if a=='static25':assert len(rr)==25
 if a=='signals':assert len(rr)<=35
 if a=='exchange':
  assert len(rr)<=30
  for k,r in rr.items():
   if k>25:assert r['move'].startswith('ex ') and float(r['static_eq'])>=float(features[p][1]['static_eq'])-35-1e-5
 if a in ['threat_wide','setup_wide']:assert len(rr)<=50
reused=0
for (p,a),rr in rows.items():
 if len(rr)!=int(next(iter(rr.values()))['candidates']) or float(next(iter(rr.values()))['wall_ms'])>=1:continue
 matches=[ss for (q,b),ss in rows.items() if q==p and b!=a and set(ss)==set(rr) and float(next(iter(ss.values()))['wall_ms'])>=1]
 assert matches
 assert any(all(rr[k]['chosen']==ss[k]['chosen'] and rr[k]['iterations']==ss[k]['iterations'] and rr[k]['sim_wp']==ss[k]['sim_wp'] and rr[k]['sim_eq']==ss[k]['sim_eq'] for k in rr) for ss in matches);reused+=1
# Every analysis position has exactly the expected main-policy structure.
for p in s['main_positions']:
 assert all((p,a) in rows and len(rows[p,a])==int(next(iter(rows[p,a].values()))['candidates']) for a in ['static25','threat_wide','setup_wide','signals','exchange','combined','reference'])
out={'main_positions_expected':320,'analysis_complete':len(s['main_positions']),'complete_arm_groups':complete_groups,'reused_groups_verified':reused,'feature_move_and_rank_identity':'passed','static_anchor_and_quota_bounds':'passed','finite_stats_and_single_choice':'passed','smoke_files':'excluded by numbered-worker glob','status':'passed'};(D/'integrity_audit.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
