import csv,json,random,math,sys
from pathlib import Path
D=Path(sys.argv[1]);s=json.loads((D/'summary.json').read_text());refs={};features={}
for f in sorted(D.glob('w[0-7].csv')):
 for r in csv.DictReader(f.open()):
  if r.get('arm')=='reference' and r.get('sim_wp') not in (None,''):refs.setdefault(int(r['pos']),{})[int(r['static_rank'])]=r
repairs={}
for r in csv.DictReader((D/'r0.csv').open()):repairs.setdefault(int(r['pos']),{})[int(r['static_rank'])]=r
for p,rr in repairs.items():
 if len(rr)==int(next(iter(rr.values()))['candidates']):refs[p]=rr
for r in csv.DictReader((D/'candidate_features.csv').open()):features.setdefault(int(r['pos']),{})[int(r['pool_index'])]=r
ps=s['main_positions'];assert all(len(refs[p])==int(next(iter(refs[p].values()))['candidates']) and float(next(iter(refs[p].values()))['wall_ms'])>=59000 for p in ps)
def stats(v):
 n=len(v);m=sum(v)/n if n else None
 return {'n':n,'mean':m,'se':math.sqrt(sum((x-m)**2 for x in v)/(n-1)/n) if n>1 else None}
def sets(p):
 ff=features[p];core={k for k,r in ff.items() if 0<int(r['global_static_rank'])<=120};base={k for k,r in ff.items() if 0<int(r['global_static_rank'])<=25};best=float(ff[1]['static_eq']);order=sorted(core,key=lambda k:int(ff[k]['global_static_rank']));out={'static25':base,'static60':set(order[:60])}
 for margin in [5,10,15,20,25,35]:out[f'band{margin}_min8']=set(order[:8])|{k for k in core if float(ff[k]['static_eq'])>=best-margin}
 for quota in [1,2,3]:
  selected=set(base)
  for tiles in range(1,8):selected.update([k for k in order if int(ff[k]['type'])==1 and int(ff[k]['tiles_played'])==tiles and float(ff[k]['static_eq'])>=best-35][:quota])
  out[f'tiles{quota}_margin35']=selected
 for quota in [1,3,5]:
  placed=sorted([k for k in core if int(ff[k]['type'])==1 and float(ff[k]['static_eq'])>=best-35],key=lambda k:(-float(ff[k]['score']),int(ff[k]['global_static_rank'])))
  out[f'score{quota}_margin35']=base|set(placed[:quota])
 exchanges=sorted([k for k,r in ff.items() if int(r['type'])==5 and float(r['static_eq'])>=best-35],key=lambda k:-float(ff[k]['static_eq']))[:5]
 out['exchange5_margin35']=base|set(exchanges);out['tiles1_exchange5_margin35']=out['tiles1_margin35']|set(exchanges)
 return out
out={'method':'retrospective independent-reference candidate coverage, not timed selector performance; maxima are noisy; no tuning claim','groups':{},'capture_main_examples':[]}
for group,pp in [('nonopening',[p for p in ps if p<6000]),('opening',[p for p in ps if p>=6000])]:
 values={}
 for p in pp:
  rr=refs[p];ss=sets(p);base=max(float(rr[k]['sim_wp']) for k in ss['static25'])
  for a,kk in ss.items():
   assert kk<=set(rr)
   v=values.setdefault(a,{'counts':[],'coverage':[],'cap':0});v['counts'].append(len(kk));v['coverage'].append(100*(max(float(rr[k]['sim_wp']) for k in kk)-base));v['cap']+=len(kk)>=120
 out['groups'][group]={a:{'candidate_count':stats(v['counts']),'candidate_range':[min(v['counts']),max(v['counts'])],'coverage_gain_pp':stats(v['coverage']),'at_least120':v['cap']} for a,v in values.items()}
seen=set()
for e in s['changed_examples']:
 if e['arm']!='combined' or e['pos']>=6000 or not e['outside_static25'] or e['wp_gain_pp']<.1:continue
 p=e['pos'];k=e['pool_index'];ss=sets(p);out['capture_main_examples'].append({'pos':p,'move':e['move'],'rank':e['global_static_rank'],'static_deficit':float(features[p][1]['static_eq'])-float(features[p][k]['static_eq']),'tiles_played':int(features[p][k]['tiles_played']),'score':float(features[p][k]['score']),'captured_by':[a for a,kk in ss.items() if k in kk]})
# Cluster bootstrap includes zero-change positions, resampling source games.
meta={int(r['pos']):r for r in csv.DictReader((D/'positions.meta.csv').open())};pp=[p for p in ps if p<6000];bygame={}
for p in pp:bygame.setdefault(int(meta[p]['game']),[]).append(p)
out['cluster_bootstrap']={};rng=random.Random(2026092999);samples=[rng.choices(list(bygame),k=len(bygame)) for _ in range(10000)]
for a in ['threat_wide','setup_wide','signals','exchange','combined']:
 delta={p:0.0 for p in pp}
 for e in s['changed_examples']:
  if e['arm']==a and e['pos'] in delta:delta[e['pos']]=e['wp_gain_pp']
 boot=sorted(sum(delta[p] for g in draw for p in bygame[g])/sum(len(bygame[g]) for g in draw) for draw in samples)
 out['cluster_bootstrap'][a]={'percentile95_pp':[boot[249],boot[9749]],'fraction_mean_le_zero':sum(x<=0 for x in boot)/len(boot),'iterations':10000,'seed':2026092999,'method':'source-game bootstrap, conditional on noisy reference values; no multiplicity correction'}
(D/'coverage_summary.json').write_text(json.dumps(out,indent=2)+'\n');print('coverage positions',len(ps));print(out['cluster_bootstrap'])
