#!/usr/bin/env python3
import csv,json,math,sys
from pathlib import Path
D=Path(sys.argv[1]);arms=['static25','threat_wide','setup_wide','signals','exchange','combined'];conditioned=['setup_conditioned','signals_conditioned','combined_conditioned'];data={}
meta={int(r['pos']):r for r in csv.DictReader((D/'positions.meta.csv').open())}
empty_board='/'.join(['15']*15)
empty_positions={int(l.split(',',1)[0]) for l in (D/'positions.cgp').read_text().splitlines() if l.split(',',1)[1].split()[0]==empty_board}
for f in sorted(list(D.glob('w[0-7].csv'))+list(D.glob('c[01].csv'))+list(D.glob('v[01].csv'))+list(D.glob('m[0-3].csv'))):
 for r in csv.DictReader(f.open()):
  if None in r or any(r.get(k) in (None,'') for k in ['pos','arm','static_rank','candidates','chosen','sim_wp','sim_eq','global_static_rank']):continue
  data.setdefault((int(r['pos']),r['arm']),{})[int(r['static_rank'])]=r
complete=lambda p,aa:all((p,a) in data and len(data[p,a])==int(next(iter(data[p,a].values()))['candidates']) and sum(int(r['chosen']) for r in data[p,a].values())==1 for a in aa)
raw_ps=sorted(p for p,a in data if a=='reference' and complete(p,arms+['reference']))
repairs={}
repair_file=D/'r0.csv'
if repair_file.exists():
 for r in csv.DictReader(repair_file.open()):
  if any(r.get(k) in (None,'') for k in ['pos','static_rank','candidates','sim_wp','sim_eq']):continue
  repairs.setdefault(int(r['pos']),{})[int(r['static_rank'])]=r
repaired=[]
for p,rr in repairs.items():
 if p not in raw_ps or len(rr)!=int(next(iter(rr.values()))['candidates']):continue
 assert set(rr)==set(data[p,'reference'])
 for k,r in rr.items():assert r['move']==data[p,'reference'][k]['move']
 data[p,'reference']=rr;repaired.append(p)
ps=[p for p in raw_ps if float(next(iter(data[p,'reference'].values()))['wall_ms'])>=59000]

cs=[p for p in ps if complete(p,conditioned)]
def stats(v,positions):
 n=len(v)
 if not n:return {'n':0,'mean':None,'se':None,'cluster_se':None,'clusters':0}
 mean=sum(v)/n;groups={}
 for p,x in zip(positions,v):
  cluster=('opening',p) if p>=6000 else ('game',int(meta[p]['game']))
  groups[cluster]=groups.get(cluster,0)+(x-mean)
 count=len(groups)
 se=math.sqrt(sum((x-mean)**2 for x in v)/(n-1)/n) if n>1 else None
 cluster_se=math.sqrt(count/(count-1)*sum(x*x for x in groups.values())/(n*n)) if count>1 else None
 return {'n':n,'mean':mean,'se':se,'cluster_se':cluster_se,'clusters':count}
def chosen(rows):
 found=[k for k,r in rows.items() if int(r['chosen'])];assert len(found)==1;return found[0]
def evaluate(positions,arm,baseline):
 nums=[];extras=[];wp=[];eq=[];coverage=[];matched=[];different=[];outside=[];exchanges=[];examples=[]
 for p in positions:
  ref=data[p,'reference'];own=data[p,arm];base=data[p,baseline];c=chosen(own);bc=chosen(base)
  assert set(own)<=set(ref) and set(base)<=set(ref)
  for k,r in own.items():assert r['move']==ref[k]['move'] and r['global_static_rank']==ref[k]['global_static_rank']
  nums.append(len(own));extras.append(len(set(own)-set(base)));different.append(c!=bc);outside.append(c not in data[p,'static25']);exchanges.append(ref[c]['move'].startswith('ex '))
  wp.append(100*(float(ref[c]['sim_wp'])-float(ref[bc]['sim_wp'])));eq.append(float(ref[c]['sim_eq'])-float(ref[bc]['sim_eq']))
  coverage.append(100*(max(float(ref[k]['sim_wp']) for k in own)-max(float(ref[k]['sim_wp']) for k in base)))
  static=sorted(ref,key=lambda k:int(ref[k]['global_static_rank']) if int(ref[k]['global_static_rank'])>0 else 1000000)[:len(own)]
  matched.append(100*(max(float(ref[k]['sim_wp']) for k in own)-max(float(ref[k]['sim_wp']) for k in static)))
  if c!=bc:
   examples.append({'pos':p,'group':'opening' if p>=6000 else 'nonopening','game':None if p>=6000 else int(meta[p]['game']),'bag':int(ref[c]['bag']),'arm':arm,'baseline_arm':baseline,'move':ref[c]['move'],'pool_index':c,'global_static_rank':int(ref[c]['global_static_rank']),'baseline_move':ref[bc]['move'],'baseline_pool_index':bc,'outside_static25':outside[-1],'wp_gain_pp':wp[-1],'equity_gain':eq[-1],'wp_sem_upper_pp':100*(float(ref[c]['sim_wp_sem'])+float(ref[bc]['sim_wp_sem'])),'eq_sem_upper':float(ref[c]['sim_eq_sem'])+float(ref[bc]['sim_eq_sem']),'addition_sources':[a for a in arms[1:-1] if c in data[p,a] and c not in data[p,'static25']]})
 return {'candidate_count':stats(nums,positions),'candidate_count_min':min(nums) if nums else None,'candidate_count_max':max(nums) if nums else None,'new_candidates':stats(extras,positions),'changed_count':sum(different),'chosen_outside_static25_count':sum(outside),'chosen_exchange_count':sum(exchanges),'selected_wp_gain_pp':stats(wp,positions),'selected_equity_gain':stats(eq,positions),'coverage_wp_gain_pp':stats(coverage,positions),'matched_count_coverage_wp_gain_pp':stats(matched,positions)},examples
out={'empty_board_positions':sorted(empty_positions),'game_derived_empty_board_count':len([p for p in empty_positions if p<6000]),'main_positions':ps,'raw_completed_main':len(raw_ps),'repaired_references':len(repaired),'pending_short_references':len(raw_ps)-len(ps),'completed_main':len(ps),'completed_conditioned_with_main_reference':len(cs),'groups':{},'changed_examples':[],'conditioned':{},'conditioned_changed_examples':[]}
for group,positions in [('nonopening',[p for p in ps if p<6000]),('opening',[p for p in ps if p>=6000]),('strict_nonopening',[p for p in ps if p not in empty_positions]),('all_empty_boards',[p for p in ps if p in empty_positions])]:
 g={'positions':len(positions),'arms':{}}
 print('\n'+group+': '+str(len(positions)))
 for arm in arms:
  result,examples=evaluate(positions,arm,'static25');g['arms'][arm]=result
  if group in ['nonopening','opening']:out['changed_examples']+=examples
  wp=result['selected_wp_gain_pp'];eq=result['selected_equity_gain'];mean=lambda s:'n/a' if s['mean'] is None else f"{s['mean']:+.4f}"
  print(f"{arm:20s} candidates {mean(result['candidate_count']):>8s} ({result['candidate_count_min']}–{result['candidate_count_max']}) changed {result['changed_count']:3d} outside25 {result['chosen_outside_static25_count']:3d} WP {mean(wp):>8s} eq {mean(eq):>8s}")
 out['groups'][group]=g
out['diagnostic_groups']={}
for group,positions in [('competitive',[p for p in ps if p<6000 and 0.01<=float(data[p,'reference'][chosen(data[p,'static25'])]['sim_wp'])<=0.99]),('tail',[p for p in ps if p<6000 and not 0.01<=float(data[p,'reference'][chosen(data[p,'static25'])]['sim_wp'])<=0.99]),('early',[p for p in ps if p<6000 and int(meta[p]['bag'])>=60]),('middle',[p for p in ps if p<6000 and 30<=int(meta[p]['bag'])<60]),('late',[p for p in ps if p<6000 and int(meta[p]['bag'])<30])]:
 out['diagnostic_groups'][group]={'positions':len(positions),'arms':{arm:evaluate(positions,arm,'static25')[0] for arm in arms}}
for group,positions in [('nonopening',[p for p in cs if p<6000]),('opening',[p for p in cs if p>=6000])]:
 g={'positions':len(positions),'arms':{},'vs_unconditioned':{}}
 for arm,old in zip(conditioned,['setup_wide','signals','combined']):
  result,examples=evaluate(positions,arm,'static25');g['arms'][arm]=result;out['conditioned_changed_examples']+=examples
  result,examples=evaluate(positions,arm,old);g['vs_unconditioned'][arm]=result
 out['conditioned'][group]=g
width_arms=['static25_fulltime','adaptive_static','static60','adaptive_signals']
width_ps=[p for p in ps if complete(p,width_arms)]
out['completed_width_with_reference']=len(width_ps);out['width']={};out['width_changed_examples']=[]
for group,positions in [('nonopening',[p for p in width_ps if p<6000]),('opening',[p for p in width_ps if p>=6000])]:
 g={'positions':len(positions),'arms':{},'fulltime_vs_ceiling_baseline':evaluate(positions,'static25_fulltime','static25')[0]}
 g['vs_static60']={arm:evaluate(positions,arm,'static60')[0] for arm in ['adaptive_static','adaptive_signals']}
 for arm in width_arms:
  result,examples=evaluate(positions,arm,'static25_fulltime');g['arms'][arm]=result;out['width_changed_examples']+=examples
 out['width'][group]=g
matched_arms=['static_setup_count','static_combined_count']
matched_ps=[p for p in ps if complete(p,matched_arms)]
out['completed_matched_with_reference']=len(matched_ps);out['matched']={};out['matched_changed_examples']=[]
for group,positions in [('nonopening',[p for p in matched_ps if p<6000]),('opening',[p for p in matched_ps if p>=6000])]:
 g={'positions':len(positions),'heuristic_vs_static_same_count':{},'static_control_vs_static25':{}}
 for original,control in zip(['setup_wide','combined'],matched_arms):
  assert all(len(data[p,original])==len(data[p,control]) for p in positions)
  result,examples=evaluate(positions,original,control);g['heuristic_vs_static_same_count'][original]=result;out['matched_changed_examples']+=examples
  g['static_control_vs_static25'][control]=evaluate(positions,control,'static25')[0]
 joined=[p for p in positions if complete(p,width_arms)]
 g['with_fulltime25_positions']=len(joined);g['static_control_vs_fulltime25']={control:evaluate(joined,control,'static25_fulltime')[0] for control in matched_arms}
 out['matched'][group]=g
out['changed_examples'].sort(key=lambda e:e['wp_gain_pp'],reverse=True);out['conditioned_changed_examples'].sort(key=lambda e:e['wp_gain_pp'],reverse=True)
(D/'summary.json').write_text(json.dumps(out,indent=2)+'\n')
print('\nConditioned rows joined to independent main reference:',len(cs))
print('Nonopening cluster errors use source games; openings use individual racks. No mixture of strata.')
