# Threat/setup candidate diversity at 15 seconds

Completed research window. Updated 2026-09-29 22:01:04 UTC. Authorized window: 19:20:59–22:00:59 UTC, 2026-09-29.

## Main finding

The stronger setup-ranking variant finds valuable candidates outside the usual static25, with the benefit concentrated late in the game. The targeted KiSTFUL and FLOUT case survives an independent sixteen-ply comparison against every static25 move. Threat contributes confirmed examples, but its average gain is less certain than setup. Exchange-only average gains are also uncertain, although the fresh EI opening example survives longer rollouts. Broader static pools also recover many of the missing moves; candidate diversity and reliable timed selection must be assessed separately.

These are estimates under static no-PAT rollouts, not measured changes in played-game strength. All gains below are win-probability **percentage points (pp)**, not relative percentages. Expected spread/equity and probability of winning can favor different plays.

## What this supports

- **Keep strategic admission separate from the final choice.** The tested setup pool averages 30.85 candidates and chooses 10 moves outside static25 across 256 nonempty positions. Six targeted promising positions retain outside 25 benefits at sixteen plies; fresh 15-second sixteen-ply selectors exploit those additions in all six. These confirmations establish examples, not a population average from the targeted subset.
- **Use adaptive width as a real option.** On 96 preselected nonempty positions, an adaptive signal pool averages 39.77 candidates versus static60, with a paired selected-value difference of −0.010 ± 0.013 pp (one SE). Its observed performance is similar with fewer candidates; no general superiority is established. Counts can shrink to 8 or expand to 125 within the finite research pool.
- **Give exchanges an admission quota when competitive.** The tested allowance is up to 5 within 35 equity points. EI, at static rank 63, gains 1.03 pp over the best static25 move at sixteen plies, and a 15-second augmented selector picks it. The second O example does not confirm; the three near-zero-WP losing-position exchanges also show no compelling benefit. This supports insurance against a missed exchange, with average strength still unresolved.
- **Do not attribute all widening benefit to checks.** Same-count static controls leave the incremental advantage uncertain: setup +0.026 ± 0.025 pp and combined +0.032 ± 0.027 pp on 96 nonempty positions. Static60 recovers many gains. The simple tile-count quota changes no choices in the fresh 40-position test; it is not established as a substitute for board-sensitive checks.
- **Keep the scope of the evidence clear.** Check time is outside the 15-second sim allowance. Late here means bag 7–29; no pre-endgame/endgame admission claim is made. More rollout depth did not systematically improve timed selection in the random secondary sample. No played-game strength comparison or production integration was done.

## Fresh primary study

256/256 nonopening positions from 128 fresh static no-PAT games, two sampled positions per game; 64/64 independent openings. Early/middle/late phases were balanced deliberately. This is not natural turn-frequency weighting. Source-game cluster errors account for two positions per game; opening errors use individual racks.

Each policy keeps static25 and adds a deduplicated union. Threat/setup checks use 64 sampled opponent racks; their computation is outside the 15-second sim budget. Each selected pool gets up to 15 seconds, four-ply static no-PAT rollout, minimum 30 iterations/play, one thread and win-probability utility. A separate 60-second round-robin whole-pool reference supplies paired selected-move comparisons. Pool: top 120 static candidates plus up to 5 legal exchanges within 35 equity points.

- **threat_wide:** static25 plus top 25 by equity−1.4×mean opponent-best reply score.
- **setup_wide:** static25 plus top 25 by equity+0.75×setup component; unchanged-board subtraction weight 0.5.
- **signals:** static25 plus top 5 pure threat and top 5 pure setup moves within 25 static-equity points.
- **exchange:** static25 plus up to 5 exchanges within 35 points.
- **combined:** union of those additions, with naturally varying width.

### Nonopening results

| Policy | Mean candidates | Chosen outside 25 | Changed choice | WP gain ± cluster SE (pp) | Equity gain ± cluster SE |
| --- | ---: | ---: | ---: | ---: | ---: |
| static25 | 25.00 | 0 | 0 | +0.000 ± 0.000 | +0.000 ± 0.000 |
| threat_wide | 32.16 | 3 | 7 | +0.014 ± 0.010 | +0.005 ± 0.095 |
| setup_wide | 30.85 | 10 | 14 | +0.046 ± 0.018 | +0.057 ± 0.120 |
| signals | 29.43 | 9 | 13 | +0.040 ± 0.016 | -0.066 ± 0.134 |
| exchange | 27.81 | 3 | 5 | +0.002 ± 0.002 | -0.118 ± 0.112 |
| combined | 41.60 | 11 | 16 | +0.046 ± 0.018 | -0.036 ± 0.172 |

Errors in the table are **one standard error**, not 95% intervals. Source-game bootstrap 95% percentile intervals, conditional on the noisy reference values and without multiplicity adjustment:

| Policy | Bootstrap 95% interval (pp) |
| --- | ---: |
| threat_wide | [-0.002, +0.037] |
| setup_wide | [+0.014, +0.082] |
| signals | [+0.012, +0.073] |
| exchange | [-0.001, +0.007] |
| combined | [+0.015, +0.082] |

### Opening results

| Policy | Mean candidates | Chosen outside 25 | Changed choice | WP gain ± cluster SE (pp) | Equity gain ± cluster SE |
| --- | ---: | ---: | ---: | ---: | ---: |
| static25 | 25.00 | 0 | 0 | +0.000 ± 0.000 | +0.000 ± 0.000 |
| threat_wide | 35.47 | 1 | 3 | -0.005 ± 0.006 | -0.014 ± 0.012 |
| setup_wide | 30.27 | 1 | 2 | +0.000 ± 0.001 | -0.002 ± 0.003 |
| signals | 30.12 | 2 | 3 | +0.005 ± 0.004 | +0.013 ± 0.012 |
| exchange | 28.12 | 2 | 3 | +0.003 ± 0.003 | +0.007 ± 0.009 |
| combined | 41.42 | 2 | 2 | +0.003 ± 0.003 | +0.005 ± 0.009 |

### Where the gains occur

| Stratum | Positions | Combined WP gain ± SE (pp) | Outside25 choices |
| --- | ---: | ---: | ---: |
| early | 85 | -0.003 ± 0.003 | 0 |
| middle | 86 | -0.002 ± 0.002 | 1 |
| late | 85 | +0.142 ± 0.054 | 10 |
| competitive | 237 | +0.049 ± 0.019 | 8 |
| tail | 19 | +0.000 ± 0.000 | 3 |

Early means bag ≥ 60, middle 30–59, late 7–29. Competitive means baseline-reference WP between 1% and 99%; tail is the complement. The phase pattern is exploratory.

## Independent long-depth confirmations

Fresh position 1217, bag 8: baseline FUSK uses three tiles and retains LOT?; KiSTFUL uses six tiles and leaves O. KiSTFUL is static rank 49, 24.756 points below the top static equity. FLOUT is rank 89, 27.767 points below. An independent 600-second, sixteen-ply sim over all static25 plus both additions found FUSK to be the best static25 move:

| Move | Win probability | Gain over best static25 | Equity gain | Conservative per-comparison WP SEM upper bound |
| --- | ---: | ---: | ---: | ---: |
| FUSK | 98.4594% | baseline | baseline | — |
| KiSTFUL | 99.8313% | +1.3719 pp | −16.4147 | 0.0490 pp |
| FLOUT | 99.4688% | +1.0095 pp | +2.7008 | 0.0588 pp |

The mean/p90/p99 immediate opponent reply-score diagnostics did not reveal a large direct threat-tail reduction. Spending the blank and playing more tiles are descriptive differences, not an established mechanism. This is a confirmed valuable admission example under the rollout model, not a population estimate.

Evidence: [new1217_all25_p16.csv](/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40/new1217_all25_p16.csv), [new1217_all25.json](/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40/new1217_all25.json), [threat_tail1217.json](/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40/threat_tail1217.json), [candidate_features.csv](/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40/candidate_features.csv).

### Five additional fresh cases

These were selected after observing outside 25 choices with primary gains ≥ 1 pp, excluding 1217. Each gets a new 300-second sixteen-ply round-robin sim against every static25 candidate, with an independent seed. Their values do not replace the primary estimate.

| Position | Candidate (static rank) | Best static25 | WP gain (pp) | WP SEM upper (pp) | Equity gain |
| ---: | --- | --- | ---: | ---: | ---: |
| 493 | e2 BUSTI (26) | m3 OB | +1.038 | 0.494 | +2.464 |
| 580 | l12 TEE (26) | l12 TET | +2.494 | 0.462 | +8.654 |
| 1100 | 15d YETT (57) | 15d YETTS | +2.450 | 0.373 | +24.533 |
| 2241 | d10 KLOOFS (34) | d11 LOOKY | +1.758 | 0.140 | +8.219 |
| 1755 | 2l NAAN (120) | 2k ANCON | +2.257 | 0.191 | +0.139 |

Completed confirmations: 5/5. Details: [validation_cases.json](/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40/validation_cases.json), [secondary_summary.json](/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40/secondary_summary.json).

### Correction to the older examples

BE retains its benefit over GIBE at six and sixteen plies. CEP reverses against COPEN: the earlier small four-ply gain becomes about −1.25 pp at six plies and−1.45 pp at sixteen. CANOE still beats the old selected ENCINAL, but a 600-second sixteen-ply evaluation over the entire static25 set finds NAP about 1.44 pp better than CANOE. A separate 300-second seed again puts NAP above CANOE, CANAL and ANAL. Thus CANOE-versus-ENCINAL alone does not establish a long-depth benefit beyond the entire static25 set.

Evidence: [horizons.json](/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40/horizons.json), [canoe_all25.json](/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40/canoe_all25.json), [alternatives941_p16.csv](/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40/alternatives941_p16.csv).

## Full-budget adaptive-width comparison

Same preselected 96 nonopening + 32 opening secondary positions; 128/128 currently joined. All distinct selections use full 15 seconds with probability cutoff disabled. Baseline is static25_fulltime. Adaptive_static takes all static moves within 15 points, minimum 8, capped by 120 available static moves. Adaptive_signals adds pure threat/setup top 5 within 25 points and exchange quota 5 within 35 points. Setup draws exclude the sampled opponent rack here. Static60 is the broad static control.

### nonopening: 96 positions

| Policy | Mean candidates | Range | Changed | WP gain ± SE (pp) | Equity gain ± SE |
| --- | ---: | --- | ---: | ---: | ---: |
| static25_fulltime | 25.00 | [25, 25] | 0 | +0.000 ± 0.000 | +0.000 ± 0.000 |
| adaptive_static | 33.04 | [8, 120] | 6 | +0.028 ± 0.024 | -0.193 ± 0.239 |
| static60 | 60.00 | [60, 60] | 11 | +0.076 ± 0.037 | -0.726 ± 0.488 |
| adaptive_signals | 39.77 | [8, 125] | 10 | +0.066 ± 0.035 | -0.250 ± 0.340 |

Fulltime25 versus ordinary ceiling-budget25: WP +0.002 ± 0.002; equity +0.025 ± 0.020.

Adaptive_signals versus static60, paired on the same positions: WP -0.010 ± 0.013; equity +0.476 ± 0.355.

### opening: 32 positions

| Policy | Mean candidates | Range | Changed | WP gain ± SE (pp) | Equity gain ± SE |
| --- | ---: | --- | ---: | ---: | ---: |
| static25_fulltime | 25.00 | [25, 25] | 0 | +0.000 ± 0.000 | +0.000 ± 0.000 |
| adaptive_static | 57.28 | [8, 120] | 2 | -0.009 ± 0.011 | -0.022 ± 0.024 |
| static60 | 60.00 | [60, 60] | 0 | +0.000 ± 0.000 | +0.000 ± 0.000 |
| adaptive_signals | 61.66 | [8, 125] | 2 | +0.009 ± 0.007 | +0.019 ± 0.017 |

Fulltime25 versus ordinary ceiling-budget25: WP +0.000 ± 0.000; equity +0.000 ± 0.000.

Adaptive_signals versus static60, paired on the same positions: WP +0.009 ± 0.007; equity +0.019 ± 0.017.

## Conditioned setup draws

128/128 preselected secondary positions joined. Remove each sampled opponent rack from the unseen pool before drawing the heuristic follow-up rack; actual engine rollouts are unchanged. These comparisons use the same independent primary reference.

| Stratum | Conditioned policy | Positions | Versus unconditioned: WP ± SE (pp) | Versus static25: WP ± SE (pp) |
| --- | --- | ---: | ---: | ---: |
| nonopening | setup_conditioned | 96 | -0.000 ± 0.004 | +0.057 ± 0.034 |
| nonopening | signals_conditioned | 96 | +0.001 ± 0.007 | +0.039 ± 0.027 |
| nonopening | combined_conditioned | 96 | +0.006 ± 0.004 | +0.067 ± 0.035 |
| opening | setup_conditioned | 32 | -0.013 ± 0.011 | -0.011 ± 0.011 |
| opening | signals_conditioned | 32 | -0.018 ± 0.018 | -0.011 ± 0.011 |
| opening | combined_conditioned | 32 | +0.002 ± 0.002 | +0.009 ± 0.007 |

## Same-count static controls

128/128 secondary positions joined. Static prefixes have exactly the corresponding primary setup_wide or combined pool count. The static controls use full 15 seconds, four plies; original heuristic selections retain their ceiling-budget protocol. Both are evaluated under the same independent reference.

### nonopening

| Heuristic vs same-count static | Positions | WP gain ± SE (pp) | Equity gain ± SE |
| --- | ---: | ---: | ---: |
| setup_wide | 96 | +0.026 ± 0.025 | -0.087 ± 0.256 |
| combined | 96 | +0.032 ± 0.027 | -0.122 ± 0.288 |

### opening

| Heuristic vs same-count static | Positions | WP gain ± SE (pp) | Equity gain ± SE |
| --- | ---: | ---: | ---: |
| setup_wide | 32 | +0.000 ± 0.000 | +0.000 ± 0.000 |
| combined | 32 | +0.007 ± 0.007 | +0.017 ± 0.017 |

| Stratum | Static control | Fulltime25 joined | Control minus fulltime25: WP ± SE (pp) |
| --- | --- | ---: | ---: |
| nonopening | static_setup_count | 96 | +0.030 ± 0.024 |
| nonopening | static_combined_count | 96 | +0.027 ± 0.024 |
| opening | static_setup_count | 32 | +0.002 ± 0.002 |
| opening | static_combined_count | 32 | +0.000 ± 0.000 |

## Rollout-depth comparison

64/64 preselected positions have complete six-ply selections and a separate 60-second six-ply reference. Compare four-ply and six-ply selected moves using that same six-ply reference, not values from different horizons.

### Six-ply nonopening: 48 positions

| Policy | Mean candidates | Range | Changed | WP gain ± SE (pp) | Equity gain ± SE |
| --- | ---: | --- | ---: | ---: | ---: |
| static25_fulltime | 25.00 | [25, 25] | 0 | +0.000 ± 0.000 | +0.000 ± 0.000 |
| adaptive_static | 37.06 | [8, 120] | 4 | +0.041 ± 0.026 | -0.746 ± 0.492 |
| static60 | 60.00 | [60, 60] | 6 | +0.071 ± 0.033 | -1.157 ± 0.643 |
| adaptive_signals | 43.23 | [8, 125] | 4 | +0.033 ± 0.026 | -0.953 ± 0.518 |

### Six-ply opening: 16 positions

| Policy | Mean candidates | Range | Changed | WP gain ± SE (pp) | Equity gain ± SE |
| --- | ---: | --- | ---: | ---: | ---: |
| static25_fulltime | 25.00 | [25, 25] | 0 | +0.000 ± 0.000 | +0.000 ± 0.000 |
| adaptive_static | 63.62 | [8, 120] | 2 | -0.130 ± 0.098 | -0.317 ± 0.226 |
| static60 | 60.00 | [60, 60] | 0 | +0.000 ± 0.000 | +0.000 ± 0.000 |
| adaptive_signals | 68.19 | [8, 125] | 2 | -0.071 ± 0.048 | -0.187 ± 0.131 |

| Stratum | Policy | Joined | Six-ply choice minus four-ply choice: WP ± SE (pp) |
| --- | --- | ---: | ---: |
| nonopening | static25_fulltime | 48 | -0.093 ± 0.041 |
| nonopening | adaptive_static | 48 | -0.088 ± 0.038 |
| nonopening | static60 | 48 | -0.050 ± 0.038 |
| nonopening | adaptive_signals | 48 | -0.096 ± 0.043 |
| opening | static25_fulltime | 16 | +0.000 ± 0.000 |
| opening | adaptive_static | 16 | -0.078 ± 0.053 |
| opening | static60 | 16 | +0.000 ± 0.000 |
| opening | adaptive_signals | 16 | -0.038 ± 0.038 |

## Targeted15-second sixteen-ply admission tests

Static25 versus static25 plus the observed valuable addition, using new selection seeds. This tests exploitation once admitted and is not a fresh general candidate-generation policy. Independent long-depth reference values evaluate both selected moves.

| Position | Static25 selection | Augmented selection | Outside25 selected? | Independent WP gain (pp) |
| ---: | --- | --- | --- | ---: |
| 493 | m3 OB | e2 BUSTI | True | +1.038 |
| 580 | l12 RET | l12 TEE | True | +2.916 |
| 1100 | ex QTT | 15d YETT | True | +2.705 |
| 2241 | d11 LOOKY | d10 KLOOFS | True | +1.758 |
| 1755 | 2k ANCON | 2l NAAN | True | +2.257 |
| 1217 | o12 FUSK | o8 KiSTFUL | True | +1.372 |

## Prospective tile-count/exchange quota

40/40 new positions complete: 32 game-derived positions from new no-PAT static games, one phase-balanced position per game, plus 8 independently generated openings. Three of the game-derived positions are first turns: the actual board split is29 nonempty positions and11 empty boards. Preserve all observations and report that actual split below. The rule was devised after observing KiSTFUL: static25 plus the highest-static-equity placement for each tiles-played count 1–7 within 35 points; optional exchange quota 5 within 35 points. Full15-second four-ply selections, separate 60-second reference.

### Nonempty board: 29 positions

| Policy | Mean candidates | Range | Changed | WP gain ± SE (pp) | Equity gain ± SE |
| --- | ---: | --- | ---: | ---: | ---: |
| static25_fulltime | 25.00 | [25, 25] | 0 | +0.000 ± 0.000 | +0.000 ± 0.000 |
| tile_quota | 25.52 | [25, 27] | 1 | -0.001 ± 0.001 | +0.294 ± 0.294 |
| tile_exchange | 27.41 | [25, 32] | 1 | -0.001 ± 0.001 | +0.294 ± 0.294 |

### Empty board: 11 positions

| Policy | Mean candidates | Range | Changed | WP gain ± SE (pp) | Equity gain ± SE |
| --- | ---: | --- | ---: | ---: | ---: |
| static25_fulltime | 25.00 | [25, 25] | 0 | +0.000 ± 0.000 | +0.000 ± 0.000 |
| tile_quota | 25.91 | [25, 27] | 0 | +0.000 ± 0.000 | +0.000 ± 0.000 |
| tile_exchange | 29.09 | [25, 32] | 2 | +0.128 ± 0.086 | +0.278 ± 0.187 |

### Fresh opening exchange discoveries

The prospective quota test discovers EI at static rank 63 on empty-board position 106 and O at static rank 76 on position 6007. Follow-ups evaluate the entire actually simulated augmented pool:32 candidates at 106,31 at 6007. Independent budgets are300 seconds at six plies and600 seconds at sixteen for 106;300 seconds at sixteen for 6007. The original selected exchange is tested separately from the best additional move found afterward in the reference; the latter is a diagnostic maximum. Fresh15-second deeper selections from the same sets are then evaluated under those independent references.

| Position | Plies | Original exchange | Best static25 | Gain (pp) | SEM upper (pp) | Best added diagnostic | Diagnostic gain (pp) |
| ---: | ---: | --- | --- | ---: | ---: | --- | ---: |
| 106 | 6 | ex EI | 8h INDIE | +1.182 | 0.206 | ex EI | +1.182 |
| 106 | 16 | ex EI | 8h INDIE | +1.030 | 0.474 | ex AEI | +1.178 |
| 6007 | 16 | ex O | 8f ONO | -0.202 | 0.626 | ex O | -0.202 |

| Position | Plies | Fresh15-second static25 selection | Augmented selection | Independent WP gain (pp) |
| ---: | ---: | --- | --- | ---: |
| 106 | 6 | 8h IDEA | ex EI | +1.496 |
| 106 | 16 | 8d DIENE | ex EI | +1.590 |
| 6007 | 16 | 8g OON | 8h ONO | +0.118 |


## Targeted exchange horizon checks

The three primary exchange-arm choices outside static25 had near-zero four-ply reference WP. Independently evaluate each against every static25 move for 180 seconds at sixteen plies. Zero sampled WP and zero sample SEM do not prove a move cannot win. These are post-outcome checks, not population averages.

| Position | Exchange (static rank) | Best static25 | Exchange WP | Best static25 WP | Gain (pp) | Equity gain |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 1124 | ex GGILLY (32) | 14k GIRLY | 0.00000% | 0.00000% | +0.000 | -9.179 |
| 2151 | ex HLUW (144) | 4f UNWET | 0.00000% | 0.00572% | -0.006 | -9.488 |
| 1542 | ex CEIIO (58) | o6 ICE | 0.00754% | 0.00377% | +0.004 | -21.006 |


## Retrospective admission diagnostics

These are observed candidate-coverage maxima under the reference, not timed selected-move gains. Larger sets have more noisy maxima; do not treat this as an unbiased tuning comparison.

| Pool rule | Mean nonopening candidates | Range | Observed coverage gain over static25 (pp) |
| --- | ---: | --- | ---: |
| static60 | 60.00 | [60, 60] | +0.045 |
| band10_min8 | 13.70 | [8, 90] | -0.004 |
| band15_min8 | 30.61 | [8, 120] | +0.026 |
| band20_min8 | 53.37 | [8, 120] | +0.042 |
| band25_min8 | 72.71 | [8, 120] | +0.047 |
| tiles1_margin35 | 25.75 | [25, 31] | +0.005 |
| tiles3_margin35 | 27.79 | [25, 40] | +0.014 |
| score1_margin35 | 25.07 | [25, 26] | +0.014 |
| exchange5_margin35 | 27.81 | [25, 30] | +0.000 |

A tile-count quota of one adds only one move at 1217 and captures KiSTFUL, but misses most other promising additions. A narrow 15-point static band misses KiSTFUL, FLOUT, YETT and KLOOFS; a generous 25-point band can grow to the 120-candidate cap. Adaptive counts therefore need both admission coverage and timed-selection testing.

## Validity, repairs and reproducibility

- All root ranking and sim rollouts disable PAT. CSW24, four/six/sixteen plies as recorded, one sim thread per worker. Win-probability-only selection; no production policy integration, commits or pushes.
- Minimum 30 iterations/play; ordinary selections can terminate at sampled WP 0/1. Cutoff 0 was initially mistaken for disabled. Seven short primary references were rerun for the intended 60 seconds with cutoff −1, preserving originals. Primary analyses use those completed repairs. Fulltime width/depth/quota/matched/admission selections disable that cutoff explicitly.
- An expanded-pool PASS sentinel caused the research harness to abort. Exclude PASS; preserve 210 complete main positions, archive original CSVs, remove only incomplete trailing positions, and resume. Preserve 113 complete conditioned positions and recover the 15 missing cases. Same candidate policy parameters remain in force.
- Main setup draws retain the original approximation that can include tiles already assigned to a sampled opponent rack. A separate conditioned study removes that rack. The heuristic also misextracts the leave of an exchange containing a blank because blank and played-through markers share the same value. Actual sim sampling and exported candidate leaves are correct; this remains a heuristic limitation, not silently changed during active comparisons.
- Threat/setup reply searches choose highest-score placements, while actual static rollouts choose by equity including leave value. This model mismatch could affect proxy rankings; no causal comparison of reply models was run.
- Candidate generation is restricted to the finite available pool. Static rank 120 examples sit at the search boundary. Sixteen-ply greedy static rollouts are a sensitivity check, not an optimal full-game oracle.
- Independent reference estimates are noisy; per-example WP SEM bounds sum both marginal SEMs conservatively because paired covariance is unavailable. Primary table errors describe variation across sampled positions, with source-game clustering. Reference noise, rollout bias, multiple policies and post-outcome follow-ups limit population conclusions.
- The first structural-quota game-seed interval overlapped the primary games. Archive it in tile_followup_overlap_excluded and exclude all of its outcomes. Regenerate the 32 games from a disjoint interval; zero exact CGP intersection is asserted for complete generated-game files. The originally preselected eight opening racks and the fixed quota rule are retained.
- Board occupancy is audited directly from CGPs. The primary split is 256 nonempty+64 empty boards. The fresh quota sample includes 29 nonempty+11 empty boards; three game-derived first turns are retained and labeled correctly, rather than silently resampled. Internal nonopening keys for the original quota stratum mean game-derived; explicit strict_nonopening/all_empty_boards keys provide the actual board split.
- Numbered worker files alone enter analysis; smoke tests, partial positions and incomplete reference repairs are excluded. The original primary sample and the prospective 40-position sample are separate. Secondary subsets were chosen without their outcomes; targeted confirmations were chosen after observing primary gains.
- Timed sim results depend on machine load as well as seeds. Later CPU-capacity queues hold worker concurrency near the machine's ten CPUs. Initial targeted validations sometimes added a worker alongside the primary and conditioning runs, so this is not an isolated single-core throughput benchmark. Immutable binaries are never overwritten while active. Keep the recorded wall times and iteration counts, not just advertised budgets.

Full methods: [README.md](/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40/README.md). Primary data/analysis: [summary.json](/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40/summary.json), [summarize.py](/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40/summarize.py), [positions.cgp](/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40/positions.cgp), [positions.meta.csv](/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40/positions.meta.csv), [manifest.json](/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40/manifest.json). Secondary analysis: [secondary_summary.json](/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40/secondary_summary.json), [secondary_summary.py](/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40/secondary_summary.py), [coverage_summary.json](/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40/coverage_summary.json), [budget_audit.json](/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40/budget_audit.json). All full worker CSVs, manifests, logs and immutable binaries are alongside this report.
