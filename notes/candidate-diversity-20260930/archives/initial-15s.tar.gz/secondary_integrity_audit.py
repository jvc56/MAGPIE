import csv,json,sys
from pathlib import Path
D=Path(sys.argv[1])
def load(files):
 data={}
 for f in files:
  for r in csv.DictReader(f.open()):
   if None in r or any(r.get(k) in (None,'') for k in ['pos','arm','static_rank','candidates','sim_wp','chosen','move']):continue
   data.setdefault((int(r['pos']),r['arm']),{})[int(r['static_rank'])]=r
 return data
def features(file):
 out={}
 for r in csv.DictReader(file.open()):out.setdefault(int(r['pos']),{})[int(r['pool_index'])]=r
 return out
F=features(D/'candidate_features.csv');TF=features(D/'tile_followup/candidate_features.csv');counts={(int(r['pos'])):(int(r['setup_count']),int(r['combined_count'])) for r in csv.DictReader((D/'matched_counts.csv').open())};out={}
for label,files,ff in [('width',D.glob('v[01].csv'),F),('depth',D.glob('d[0-3].csv'),F),('conditioned',D.glob('c[01].csv'),F),('matched',D.glob('m[0-3].csv'),F),('tile',(D/'tile_followup').glob('w[01].csv'),TF)]:
 data=load(files);complete=0
 for (p,a),rr in data.items():
  if len(rr)!=int(next(iter(rr.values()))['candidates']):continue
  complete+=1;assert sum(int(r['chosen']) for r in rr.values())==1
  for k,r in rr.items():assert r['move']==ff[p][k]['move'] and r['global_static_rank']==ff[p][k]['global_static_rank'] and abs(float(r['static_eq'])-float(ff[p][k]['static_eq']))<1e-5
  m=float(next(iter(rr.values()))['wall_ms'])
  if label!='conditioned':assert m>= (59000 if a=='reference' else 14900) or m<1
  if a=='reference':assert set(rr)==set(ff[p]);continue
  core={k for k,r in ff[p].items() if 0<int(r['global_static_rank'])<=120};best=float(ff[p][1]['static_eq']);exchanges=sorted([k for k,r in ff[p].items() if int(r['type'])==5 and float(r['static_eq'])>=best-35],key=lambda k:-float(ff[p][k]['static_eq']))[:5]
  if a=='static25_fulltime':assert set(rr)==set(range(1,26))
  if a=='static60':assert set(rr)==set(range(1,61))
  if a=='adaptive_static':assert set(rr)==(set(range(1,9))|{k for k in core if float(ff[p][k]['static_eq'])>=best-15})
  if a=='adaptive_signals':
   static=set(range(1,9))|{k for k in core if float(ff[p][k]['static_eq'])>=best-15};assert static<=set(rr)
   assert all(k in exchanges or float(ff[p][k]['static_eq'])>=best-25 for k in set(rr)-static)
  if label=='matched':
   target=counts[p][0 if a=='static_setup_count' else 1];assert set(rr)==set(range(1,target+1))
  if label=='tile' and a in ['tile_quota','tile_exchange']:
   selected=set(range(1,26));order=sorted(core,key=lambda k:int(ff[p][k]['global_static_rank']))
   for tiles in range(1,8):
    possible=[k for k in order if int(ff[p][k]['type'])==1 and int(ff[p][k]['tiles_played'])==tiles and float(ff[p][k]['static_eq'])>=best-35]
    if possible:selected.add(possible[0])
   if a=='tile_exchange':selected|=set(exchanges)
   assert set(rr)==selected
 out[label]={'complete_arm_groups':complete,'identity_and_count_rules':'passed','full_budget_rules':'passed' if label!='conditioned' else 'ceiling protocol preserved'}
(D/'secondary_integrity_audit.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
