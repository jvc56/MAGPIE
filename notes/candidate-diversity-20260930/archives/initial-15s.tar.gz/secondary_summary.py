import csv,json,math,sys
from pathlib import Path
D=Path(sys.argv[1]); A=['static25_fulltime','adaptive_static','static60','adaptive_signals']
def load(files):
 data={}
 for f in files:
  if not f.exists():continue
  for r in csv.DictReader(f.open()):
   if None in r or any(r.get(k) in (None,'') for k in ['pos','arm','static_rank','candidates','chosen','sim_wp','sim_eq','move']):continue
   data.setdefault((int(r['pos']),r['arm']),{})[int(r['static_rank'])]=r
 return data
def complete(data,p,arms):
 return all((p,a) in data and len(data[p,a])==int(next(iter(data[p,a].values()))['candidates']) and sum(int(r['chosen']) for r in data[p,a].values())==1 for a in arms)
def choose(rr):return next(k for k,r in rr.items() if int(r['chosen']))
def stats(v):
 n=len(v);m=sum(v)/n if n else None
 return {'n':n,'mean':m,'se':math.sqrt(sum((x-m)**2 for x in v)/(n-1)/n) if n>1 else None}
def compare(picks,base,refs,positions):
 wp=[];eq=[];changed=[];outside=[];nums=[];exchanges=[];examples=[];coverage=[]
 for p in positions:
  rr=refs[p];own=picks[p];bb=base[p];c=choose(own);b=choose(bb)
  assert set(own)<=set(rr) and set(bb)<=set(rr)
  for k,r in own.items():assert r['move']==rr[k]['move'] and r['global_static_rank']==rr[k]['global_static_rank']
  gain=100*(float(rr[c]['sim_wp'])-float(rr[b]['sim_wp']));q=float(rr[c]['sim_eq'])-float(rr[b]['sim_eq'])
  wp.append(gain);eq.append(q);changed.append(c!=b);outside.append(c not in bb);nums.append(len(own));exchanges.append(rr[c]['move'].startswith('ex '));coverage.append(100*(max(float(rr[k]['sim_wp']) for k in own)-max(float(rr[k]['sim_wp']) for k in bb)))
  if c!=b:examples.append({'pos':p,'move':rr[c]['move'],'rank':int(rr[c]['global_static_rank']),'pool_index':c,'baseline_move':rr[b]['move'],'baseline_pool_index':b,'outside_baseline':c not in bb,'wp_gain_pp':gain,'equity_gain':q,'wp_sem_upper_pp':100*(float(rr[c]['sim_wp_sem'])+float(rr[b]['sim_wp_sem']))})
 return {'candidate_count':stats(nums),'count_range':[min(nums),max(nums)] if nums else None,'changed_count':sum(changed),'chosen_outside_baseline':sum(outside),'chosen_exchange_count':sum(exchanges),'selected_wp_gain_pp':stats(wp),'selected_equity_gain':stats(eq),'coverage_wp_gain_pp':stats(coverage),'examples':sorted(examples,key=lambda e:e['wp_gain_pp'],reverse=True)}
# Six-ply choices and four-ply choices judged with the same six-ply reference.
depth=load(sorted(D.glob('d[0-3].csv')));width=load(sorted(D.glob('v[01].csv')))
ps=sorted({p for p,a in depth if a=='reference' and complete(depth,p,A+['reference']) and float(next(iter(depth[p,'reference'].values()))['wall_ms'])>=59000})
refs={p:depth[p,'reference'] for p in ps};out={'completed_depth':len(ps),'depth':{},'four_vs_six':{}}
for group,pp in [('nonopening',[p for p in ps if p<6000]),('opening',[p for p in ps if p>=6000])]:
 base={p:depth[p,A[0]] for p in pp};out['depth'][group]={'positions':len(pp),'arms':{a:compare({p:depth[p,a] for p in pp},base,refs,pp) for a in A}}
 joined=[p for p in pp if complete(width,p,A)];out['four_vs_six'][group]={'positions':len(joined),'six_minus_four':{},'four_against_six_baseline':{}}
 for a in A:
  out['four_vs_six'][group]['six_minus_four'][a]=compare({p:depth[p,a] for p in joined},{p:width[p,a] for p in joined},refs,joined)
  out['four_vs_six'][group]['four_against_six_baseline'][a]=compare({p:width[p,a] for p in joined},base,refs,joined)
# Prospective structural quota sample: one position per new game, openings separate.
T=D/'tile_followup';empty_board='/'.join(['15']*15);tile_empty={int(l.split(',',1)[0]) for l in (T/'positions.cgp').read_text().splitlines() if l.split(',',1)[1].split()[0]==empty_board};out['tile_empty_board_positions']=sorted(tile_empty);data=load(sorted(T.glob('w[01].csv')));aa=['static25_fulltime','tile_quota','tile_exchange'];ps=sorted({p for p,a in data if a=='reference' and complete(data,p,aa+['reference']) and float(next(iter(data[p,'reference'].values()))['wall_ms'])>=59000});refs={p:data[p,'reference'] for p in ps};out['completed_tile']=len(ps);out['tile']={}
for group,pp in [('nonopening',[p for p in ps if p<6000]),('opening',[p for p in ps if p>=6000]),('strict_nonopening',[p for p in ps if p not in tile_empty]),('all_empty_boards',[p for p in ps if p in tile_empty])]:
 base={p:data[p,aa[0]] for p in pp};out['tile'][group]={'positions':len(pp),'arms':{a:compare({p:data[p,a] for p in pp},base,refs,pp) for a in aa}}
# Independently seeded targeted long-depth confirmations; selected after observing initial gains.
out['fresh_validations']=[]
for e in json.loads((D/'validation_cases.json').read_text())['cases']:
 p=e['pos'];f=D/f'new{p}_all25_p16.csv'
 if not f.exists():continue
 rr=load([f]).get((p,'reference'),{})
 if len(rr)!=26 or float(next(iter(rr.values()))['wall_ms'])<299000:continue
 b=max(range(1,26),key=lambda k:float(rr[k]['sim_wp']));c=e['pool_index'];n=rr[c];base=rr[b]
 out['fresh_validations'].append({'pos':p,'move':n['move'],'rank':int(n['global_static_rank']),'best_static25_move':base['move'],'best_static25_rank':int(base['global_static_rank']),'candidate_wp':float(n['sim_wp']),'best_static25_wp':float(base['sim_wp']),'wp_gain_pp':100*(float(n['sim_wp'])-float(base['sim_wp'])),'wp_sem_upper_pp':100*(float(n['sim_wp_sem'])+float(base['sim_wp_sem'])),'equity_gain':float(n['sim_eq'])-float(base['sim_eq']),'eq_sem_upper':float(n['sim_eq_sem'])+float(base['sim_eq_sem'])})
out['prospective_exchange_validation']=[]
for p,plies,budget,expected_count,original_index,original_move in [(106,6,300000,32,63,'ex EI'),(106,16,600000,32,63,'ex EI'),(6007,16,300000,31,76,'ex O')]:
 rr=load([D/f'tile_followup/validate{p}_p{plies}.csv']).get((p,'reference'),{})
 if len(rr)!=expected_count or float(next(iter(rr.values()))['wall_ms'])<budget-1000:continue
 b=max(range(1,26),key=lambda k:float(rr[k]['sim_wp']));c=original_index;best_extra=max([k for k in rr if k>25],key=lambda k:float(rr[k]['sim_wp']));n=rr[c];base=rr[b];assert n['move']==original_move
 result={'pos':p,'plies':plies,'original_exchange':n['move'],'original_exchange_wp':float(n['sim_wp']),'best_static25':base['move'],'best_static25_wp':float(base['sim_wp']),'original_exchange_gain_pp':100*(float(n['sim_wp'])-float(base['sim_wp'])),'original_exchange_sem_upper_pp':100*(float(n['sim_wp_sem'])+float(base['sim_wp_sem'])),'original_exchange_equity_gain':float(n['sim_eq'])-float(base['sim_eq']),'best_added_diagnostic':rr[best_extra]['move'],'best_added_wp':float(rr[best_extra]['sim_wp']),'best_added_gain_pp':100*(float(rr[best_extra]['sim_wp'])-float(base['sim_wp'])),'best_added_sem_upper_pp':100*(float(rr[best_extra]['sim_wp_sem'])+float(base['sim_wp_sem']))}
 own=load([D/f'tile_followup/admission{p}_p{plies}.csv'])
 if complete(own,p,['static25_fulltime','static25_admitted']):
  c=choose(own[p,'static25_admitted']);b=choose(own[p,'static25_fulltime']);result['timed_selection']={'baseline_move':rr[b]['move'],'augmented_move':rr[c]['move'],'outside25':c>25,'paired':compare({p:own[p,'static25_admitted']},{p:own[p,'static25_fulltime']},{p:rr},[p])}
 out['prospective_exchange_validation'].append(result)
out['exchange_validations']=[]
for e in json.loads((D/'exchange_validation_manifest.json').read_text())['cases']:
 p=e['pos'];rr=load([D/f'exchange{p}_all25_p16.csv']).get((p,'reference'),{})
 if len(rr)!=26 or float(next(iter(rr.values()))['wall_ms'])<179000:continue
 b=max(range(1,26),key=lambda k:float(rr[k]['sim_wp']));c=e['pool_index'];n=rr[c];base=rr[b];assert n['move']==e['move']
 out['exchange_validations'].append({'pos':p,'move':n['move'],'rank':int(n['global_static_rank']),'best_static25_move':base['move'],'candidate_wp':float(n['sim_wp']),'best_static25_wp':float(base['sim_wp']),'wp_gain_pp':100*(float(n['sim_wp'])-float(base['sim_wp'])),'wp_sem_upper_pp':100*(float(n['sim_wp_sem'])+float(base['sim_wp_sem'])),'equity_gain':float(n['sim_eq'])-float(base['sim_eq'])})
out['admission_tests']=[]
for p in [493,580,1100,2241,1755,1217]:
 own=load([D/f'admission{p}_p16.csv']);rr=load([D/f'new{p}_all25_p16.csv']).get((p,'reference'),{})
 if not complete(own,p,['static25_fulltime','static25_admitted']) or len(rr) not in [26,27] or float(next(iter(rr.values()))['wall_ms'])<(599000 if p==1217 else 299000):continue
 result=compare({p:own[p,'static25_admitted']},{p:own[p,'static25_fulltime']},{p:rr},[p]);c=choose(own[p,'static25_admitted']);b=choose(own[p,'static25_fulltime'])
 out['admission_tests'].append({'pos':p,'baseline_move':rr[b]['move'],'admitted_selection':rr[c]['move'],'admitted_selected_outside25':c>25,'baseline_wp':float(rr[b]['sim_wp']),'admitted_wp':float(rr[c]['sim_wp']),'paired':result})
(D/'secondary_summary.json').write_text(json.dumps(out,indent=2)+'\n');print({k:v for k,v in out.items() if k.startswith('completed')});print('fresh validations:',len(out['fresh_validations']))
