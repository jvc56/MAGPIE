# Extended candidate-diversity research

User-authorized window: 2026-09-29 12:20:59–15:00:59 America/Los_Angeles (19:20:59–22:00:59 UTC). No production integration, commits or pushes.

## Fresh sample

128 independent static no-PAT self-play games from seed2026092919 produced2299 CGPs with bag>=7. Sample two nonopening positions per game from different phases, rotating phases across games: early bag>=60; middle30–59; late7–29. Selection seed2026092921. The resulting256 positions have approximately balanced phase representation, not the natural frequency of turns. Metadata preserve game IDs for clustered errors. Add64 independent opening racks from seed2026092920. The previous144-position dataset is not reused.

## Policies fixed before outcomes

Pool: top120 static candidates plus up to5 legal exchanges within35 equity points of the top static play. Exchanges are generated separately; quota includes exchanges already in the pool/anchor. PAT is disabled for both players in initial ranking and all sim rollouts.

All policies retain the usual top25 static anchor and add candidates by deduplicated union. No common-width padding/truncation.

- static25: anchor only.
- threat_wide: add top25 by static equity minus1.4 times mean opponent-best reply score (double the prior0.7 weight).
- setup_wide: add top25 by static equity plus0.75 times the setup component (triple the prior0.25 weight; unchanged-board baseline weight remains0.5).
- signals: add top5 by pure threat component and top5 by pure setup component, each restricted to moves within25 static-equity points of the best static play.
- exchange: add up to5 eligible exchanges within35 points.
- combined: union of all additions.

Threat/setup use64 partitioned opponent racks, full greedy score replies, one follow-up rack per opponent rack and no early elimination. Check computation is outside the sim time budget. The main run deliberately retains the earlier setup draw approximation, allowing a separately controlled conditioning test.

## Simulation and independent evaluation

Each distinct selected set is allowed15 seconds, four plies, one thread, minimum30 iterations/play, win-probability-only utility and top-two IDS sampling. Identical candidate sets reuse the same result. The engine can stop before the ceiling in degenerate-utility cases; recorded wall_ms and iterations expose this. Policy order rotates by position ID.

Each position gets a separate60-second, round-robin, four-ply no-PAT reference sim across the whole pool with an independent seed. Primary comparisons use the reference value of each policy's selected move versus the baseline's selected move. The reference is noisy and not game-play ground truth. Candidate-coverage maxima are secondary diagnostics. Static same-count coverage controls do not constrain policy widths.

## Conditioned setup sub-study

Code audit found that the original setup follow-up draws include tiles in the sampled opponent rack. The secondary variant removes that sampled rack from the unseen pool before shuffling the follow-up draw; a common draw prefix remains shared across candidates. This changes heuristic ranking only; the engine's rollout sampling is unchanged.

Randomly select96 source games and one of their two sampled positions per game, plus32 random opening racks (seed2026092922), without using reference outcomes. Run fresh15-second selections for setup_conditioned, signals_conditioned and combined_conditioned. Join them to the main independent reference, checking identical move identities and global static ranks. Compare both to static25 and their corresponding unconditioned policies. This sub-study does not regenerate the independent reference.

## Analysis

Report opening and nonopening strata separately, and track competitive positions (baseline independent-reference WP between1% and99%) separately from tail positions. Report both equity and WP; saturation can produce tiny WP differences alongside large equity changes. Source-game cluster standard errors account for the two positions per no-PAT self-play game; openings use individual racks. Partial positions are excluded. Conditioning comparisons use only fully joined pairs.

Record all changed choices, including negative and within-anchor changes, to distinguish meaningful novel-candidate benefit from selection noise or utility tradeoffs. Any follow-up long sims are secondary validations and never replace the primary estimates. Offline score sweeps are exploratory; select tuning rules using a fixed source-game split before assessing held-out coverage.

Reproduce with launch.sh, launch_conditioned.sh and summarize.py. Both immutable binaries, SHA256 manifests, source snapshots, CGPs and full worker CSVs/logs are preserved here. All workers check the user window deadline between positions.

## Reference cutoff audit and full-budget width study

The engine treats cutoff=0 as stopping at sampled WP exactly0 or1, not as disabling the cutoff. Some main reference runs therefore stopped after30 samples/play. A separately preserved reference binary uses cutoff=-1 (outside the probability range), round-robin sampling and the same independent reference seed, extending those evaluations to the intended60 seconds. repair_references.py detects all short references and reevaluates them. Analysis excludes them until a complete repaired reference is available; original rows remain intact. The active selection policies are not retroactively changed. Competitive/tail classification uses the corrected reference values.

The width study was revised before it started: all its selections disable this cutoff, allowing full15-second comparisons. It uses the same preselected96+32 sample as the conditioning study and starts after that study finishes, in two workers. Four policies:

- static25_fulltime: usual25, with early probability cutoff disabled.
- adaptive_static: retain static candidates within15 equity points of the top play, with a minimum8 and cap at the available static pool120. Thus it can shrink or grow.
- static60: a wider fixed static comparison.
- adaptive_signals: adaptive_static plus top5 pure threat and top5 pure conditioned setup components within25 points, plus the generous exchange quota5 within35 points.

Primary width comparisons use static25_fulltime as their baseline. Compare fulltime baseline to the ordinary ceiling-budget baseline separately. Record when the adaptive static band reaches the120-candidate pool cap. The original width smoke binary with probability cutoff is preserved separately; the manifest records the pre-outcome revision and both hashes.

Six- and sixteen-ply independent-seed validations of the three older examples use120 seconds and two candidates. Their recorded wall times are audited. A further600-second sixteen-ply evaluation compares CANOE to every original static25 candidate. These are targeted secondary analyses, not added to the fresh sample's primary averages.


## Expanded-pool pass boundary and recovery

The research harness admitted PASS at the tail of move generation when fewer than120 actual candidates existed; converting its sentinel equity aborted the process. Exclude PASS unconditionally from this simulation candidate pool. Preserve210 completed main positions, archive original worker CSVs, remove only incomplete trailing positions, and resume with the fixed binary. The conditioned run likewise preserved113 complete positions; only its15 missing cases are retried. Its queued width run had not started because the conditioning status reported failure; start width separately with the fixed binary and the same preselected sample. No completed policy outcome is changed by this recovery.

## Deeper selection and prospective structural quota

Randomly choose48 nonopening and16 opening positions from the preselected secondary sample (seed2026092961) for full15-second six-ply selectors and a60-second independent six-ply round-robin reference. Evaluate both four-ply and six-ply choices under that same six-ply reference, rather than comparing values from different horizons directly. Four workers start when no more than two main workers remain.

After discovering KiSTFUL, define an exploratory structural rule: retain static25 and add the highest-static-equity placement for each tiles-played count1–7, provided it is within35 points. Test this rule and its union with the exchange quota on32 new no-PAT static games (seed2026100100), one phase-balanced nonopening position per game (sampling2026092982), and8 new opening racks (seed2026092981). Selection seed2026092983; three arms, full15 seconds, four plies; independent60-second whole-pool reference. This is prospective for these40 positions, but the rule arose after observing the primary sample. The tile mode skips heuristic checks; its threat/setup CSV fields are placeholders equal to static equity. Exclude its earlier incorrect smoke, which omitted the baseline; smoke_v3 verifies all intended arms and recorded wall budgets.

Targeted sixteen-ply validations compare five additional outside25 choices with observed primary gains>=1pp to every static25 candidate,300 seconds each and independent seeds. These cases were selected after seeing primary results and are confirmations of examples, not unbiased population averages.

All scripts, original/updated manifests, immutable binaries and source snapshots are preserved. secondary_summary.py reports depth, structural quota and fresh long-depth confirmations. coverage_summary.py reports retrospective pool coverage separately from timed performance; its maxima are noisy and cannot establish a policy's selected-move gain. Its source-game bootstrap is conditional on the reference estimates and does not adjust for multiple policy comparisons.


## Same-count static controls

For the same preselected96 nonopening+32 opening positions, simulate two static prefixes whose candidate counts exactly equal that position's setup_wide and combined pools. Counts are read from the main worker CSVs, without reference outcomes. These controls use full15-second four-ply no-PAT simulations and join to the independent main reference. Four workers reuse the depth-study slots after depth finishes. Compare the corresponding heuristic policy to its static same-count control, and report the static controls against both the ordinary baseline and the fulltime25 baseline. This is a secondary post-primary design; no common padding or truncation is added to the heuristic pools. ItsCSV threat/setup fields are placeholders equal to static equity because it needs no check computation.

The setup heuristic also treats the exchanged-blank marker as a played-through board square when extracting the leave. This is a remaining heuristic approximation affecting blank-containing exchanges; engine simulations and exported candidate leaves do not have this problem. Keep the original heuristic consistent during these comparisons and record the limitation rather than silently changing active protocols.


## Targeted candidate-admission check

For the same six observed strong-gain positions, run fresh15-second sixteen-ply selections from static25 versus static25 plus that observed outside candidate (both KiSTFUL andFLOUT at1217). Disable probability cutoffs, use independent selection seeds2026093000+position, and evaluate the choices using the separate300/600-second sixteen-ply reference over exactly those sets. This is a targeted admission test, not a new candidate-generation policy or a representative average. It tests whether the shorter selection budget exploits a valuable candidate once admitted. The CSV heuristic fields are static placeholders; no check computation is required.


## Prospective-game seed overlap correction

A seed-range audit found that the first tile-quota generator used2026092980..2026093011, inside the primary generator's2026092919..2026093046 interval. Stop its two workers, archive all data in tile_followup_overlap_excluded, and exclude all those outcomes. Restart the32-game sample with2026100100..2026100131. Assert zero exact CGP intersection across the complete primary and corrected generated-game files. Preserve the eight independently generated opening racks that were preselected before this quota study; the rule and sampling procedure are unchanged. The updated tile manifest records the correction. Primary sampled nonopening/opening CGPs also have zero exact intersection.


## Exchange horizon checks

The three primary exchange-arm choices outside static25 are checked independently against the entire static25 set for180 seconds at sixteen plies. Their four-ply WP values were near zero. These targeted post-outcome checks assess horizon sensitivity of rare-win estimates; all-zero sampled values and SEMs are not proofs of impossibility. Candidate names/ranks come from the verified feature export, and no corresponding reference values enter primary averages.


## Actual board occupancy

The primary256 game-derived sample is entirely nonempty, as intended;64 independent opening racks are empty. The quota follow-up's phase sampler selected three first turns among its32 game-derived positions. Retain the prespecified sample and all outcomes; additionally report the actual29 nonempty/11 empty board split. The exchange discovery at106 is an opening. The raw internal nonopening key for quota's original32-position stratum means game-derived; strict_nonopening andall_empty_boards explicitly give the occupancy-correct comparisons. No positions are removed or resampled after seeing outcomes.
