#!/usr/bin/env python3
import csv,json,os,subprocess,time
from pathlib import Path
D=Path('/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40');repo='/Users/olaugh/sources/magpie-pat-simcmp';deadline=1790719259
lines={int(x.split(',',1)[0]):x for x in (D/'positions.cgp').read_text().splitlines()}
def completed(files):
 data={}
 for f in files:
  if not f.exists():continue
  for r in csv.DictReader(f.open()):
   if r.get('arm')!='reference' or any(r.get(k) in (None,'') for k in ['pos','static_rank','candidates','wall_ms']):continue
   data.setdefault(int(r['pos']),{})[int(r['static_rank'])]=r
 return {p:rr for p,rr in data.items() if len(rr)==int(next(iter(rr.values()))['candidates'])}
while not (D/'canoe_all25_status.txt').exists() and time.time()<deadline-62:time.sleep(10)
while time.time()<deadline-62:
 original=completed(sorted(D.glob('w[0-7].csv')));repaired=completed([D/'r0.csv'])
 pending=sorted(p for p,rr in original.items() if float(next(iter(rr.values()))['wall_ms'])<59000 and p not in repaired)
 if not pending:
  if (D/'status.txt').exists():break
  time.sleep(10);continue
 pos=pending[0];(D/'repair_current.cgp').write_text(lines[pos]+'\n')
 env=os.environ.copy();env.update(PCD_ADAPTIVE='1',PCD_REF_ONLY='1',PCD_POOL='120',PCD_EXCHANGE_QUOTA='5',PCD_EXCHANGE_MARGIN='35',PCD_IN=str(D/'repair_current.cgp'),PCD_OUT=str(D/'r0.csv'),PCD_REF_MS='60000',PCD_PLIES='4',PCD_DEADLINE=str(deadline))
 with (D/'repair_worker.log').open('a') as log:
  proc=subprocess.Popen([str(D/'magpie_test_reference'),'patcanddiversity'],cwd=repo,env=env,stdout=log,stderr=log)
  (D/'repair_pid.txt').write_text(str(proc.pid)+'\n')
  if proc.wait()!=0:raise RuntimeError(f'reference repair failed for{pos}')
 print('Repaired reference',pos,flush=True)
(D/'repair_status.json').write_text(json.dumps({'finished_epoch':time.time(),'complete_repairs':len(completed([D/'r0.csv'])),'deadline_reached':time.time()>=deadline-62},indent=2)+'\n')
