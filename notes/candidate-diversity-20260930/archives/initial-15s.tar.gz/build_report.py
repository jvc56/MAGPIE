import json,sys,datetime,re
from pathlib import Path
D=Path(sys.argv[1]).resolve();s=json.loads((D/'summary.json').read_text());t=json.loads((D/'secondary_summary.json').read_text());c=json.loads((D/'coverage_summary.json').read_text());a=json.loads((D/'budget_audit.json').read_text());final=len(sys.argv)>2 and sys.argv[2]=='final'
def link(name):return f'[{name}]({D/name})'
def n(x,d=3):return '—' if x is None else f'{x:+.{d}f}'
def metric(r,key='selected_wp_gain_pp',cluster=True):
 z=r[key];se=z.get('cluster_se') if cluster else z.get('se');return f"{n(z['mean'])} ± {n(se).lstrip('+')}"
def table(rows):return '\n'.join('| '+' | '.join(map(str,r))+' |' for r in rows)+'\n'
def policy_table(g):
 rows=[['Policy','Mean candidates','Chosen outside25','Changed choice','WP gain ± cluster SE (pp)','Equity gain ± cluster SE'],['---','---:','---:','---:','---:','---:']]
 for arm,r in g['arms'].items():rows.append([arm,f"{r['candidate_count']['mean']:.2f}" if r['candidate_count']['mean'] is not None else '—',r['chosen_outside_static25_count'],r['changed_count'],metric(r),metric(r,'selected_equity_gain')])
 return table(rows)
def secondary_table(g,cluster=False):
 rows=[['Policy','Mean candidates','Range','Changed','WP gain ± SE (pp)','Equity gain ± SE'],['---','---:','---','---:','---:','---:']]
 for arm,r in g['arms'].items():
  rng=r.get('count_range',[r.get('candidate_count_min'),r.get('candidate_count_max')]);rows.append([arm,f"{r['candidate_count']['mean']:.2f}" if r['candidate_count']['mean'] is not None else '—',str(rng),r['changed_count'],metric(r,cluster=cluster),metric(r,'selected_equity_gain',cluster)])
 return table(rows)
all_complete=s['completed_main']==320 and s['completed_conditioned_with_main_reference']==128 and s['completed_width_with_reference']==128 and s['completed_matched_with_reference']==128 and t['completed_depth']==64 and t['completed_tile']==40 and len(t['fresh_validations'])==5 and len(t['prospective_exchange_validation'])==3 and all('timed_selection' in e for e in t['prospective_exchange_validation'])
status='Completed research window' if final else ('Experiments complete; final audit in progress' if all_complete else 'Draft; ongoing studies are partial')
lines=[f'# Threat/setup candidate diversity at15 seconds\n\n{status}. Updated {datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")}. Authorized window:19:20:59–22:00:59UTC,2026-09-29.\n',
'''## Main finding

The stronger setup-ranking variant finds valuable candidates outside the usual static25, with the benefit concentrated late in the game. The targeted KiSTFUL andFLOUT case survives an independent sixteen-ply comparison against every static25 move. Threat contributes confirmed examples, but its average gain is less certain than setup. Exchange-only average gains are also uncertain, although the fresh EI opening example survives longer rollouts. Broader static pools also recover many of the missing moves; candidate diversity and reliable timed selection must be assessed separately.

These are estimates under static no-PAT rollouts, not measured changes in played-game strength. All gains below are win-probability **percentage points (pp)**, not relative percentages. Expected spread/equity and probability of winning can favor different plays.
''',
"""## What this supports

- **Keep strategic admission separate from the final choice.** The tested setup pool averages30.85 candidates and chooses10 moves outside static25 across256 nonempty positions. Six targeted promising positions retain outside25 benefits at sixteen plies; fresh15-second sixteen-ply selectors exploit those additions in all six. These confirmations establish examples, not a population average from the targeted subset.
- **Use adaptive width as a real option.** On96 preselected nonempty positions, an adaptive signal pool averages39.77 candidates versus static60, with a paired selected-value difference of−0.010±0.013pp (one SE). Its observed performance is similar with fewer candidates; no general superiority is established. Counts can shrink to8 or expand to125 within the finite research pool.
- **Give exchanges an admission quota when competitive.** The tested allowance is up to5 within35 equity points. EI, at static rank63, gains1.03pp over the best static25 move at sixteen plies, and a15-second augmented selector picks it. The second O example does not confirm; the three near-zero-WP losing-position exchanges also show no compelling benefit. This supports insurance against a missed exchange, with average strength still unresolved.
- **Do not attribute all widening benefit to checks.** Same-count static controls leave the incremental advantage uncertain: setup+0.026±0.025pp and combined+0.032±0.027pp on96 nonempty positions. Static60 recovers many gains. The simple tile-count quota changes no choices in the fresh40-position test; it is not established as a substitute for board-sensitive checks.
- **Keep the scope of the evidence clear.** Check time is outside the15-second sim allowance. Late here means bag7–29; no pre-endgame/endgame admission claim is made. More rollout depth did not systematically improve timed selection in the random secondary sample. No played-game strength comparison or production integration was done.

""",
'## Fresh primary study\n',
f"{s['groups']['nonopening']['positions']}/256 nonopening positions from128 fresh static no-PAT games, two sampled positions per game; {s['groups']['opening']['positions']}/64 independent openings. Early/middle/late phases were balanced deliberately. This is not natural turn-frequency weighting. Source-game cluster errors account for two positions per game; opening errors use individual racks.\n\nEach policy keeps static25 and adds a deduplicated union. Threat/setup checks use64 sampled opponent racks; their computation is outside the15-second sim budget. Each selected pool gets up to15 seconds, four-ply static no-PAT rollout, minimum30 iterations/play, one thread and win-probability utility. A separate60-second round-robin whole-pool reference supplies paired selected-move comparisons. Pool: top120 static candidates plus up to5 legal exchanges within35 equity points.\n\n",
'''- **threat_wide:** static25 plus top25 by equity−1.4×mean opponent-best reply score.
- **setup_wide:** static25 plus top25 by equity+0.75×setup component; unchanged-board subtraction weight0.5.
- **signals:** static25 plus top5 pure threat and top5 pure setup moves within25 static-equity points.
- **exchange:** static25 plus up to5 exchanges within35 points.
- **combined:** union of those additions, with naturally varying width.

''',
'### Nonopening results\n\n',policy_table(s['groups']['nonopening']),
'\nErrors in the table are **one standard error**, not95% intervals. Source-game bootstrap95% percentile intervals, conditional on the noisy reference values and without multiplicity adjustment:\n\n']
rows=[['Policy','Bootstrap95% interval (pp)'],['---','---:']]
for arm,r in c['cluster_bootstrap'].items():rows.append([arm,f"[{n(r['percentile95_pp'][0])}, {n(r['percentile95_pp'][1])}]"])
lines+=[table(rows),'\n### Opening results\n\n',policy_table(s['groups']['opening']),'\n### Where the gains occur\n\n']
rows=[['Stratum','Positions','Combined WP gain ± SE (pp)','Outside25 choices'],['---','---:','---:','---:']]
for g in ['early','middle','late','competitive','tail']:
 r=s['diagnostic_groups'][g]['arms']['combined'];rows.append([g,s['diagnostic_groups'][g]['positions'],metric(r),r['chosen_outside_static25_count']])
lines+=[table(rows),'\nEarly means bag≥60, middle30–59, late7–29. Competitive means baseline-reference WP between1% and99%; tail is the complement. The phase pattern is exploratory.\n',
'## Independent long-depth confirmations\n\n',
'''Fresh position1217, bag8: baseline FUSK uses three tiles and retainsLOT?; KiSTFUL uses six tiles and leavesO. KiSTFUL is static rank49,24.756 points below the top static equity. FLOUT is rank89,27.767 points below. An independent600-second, sixteen-ply sim over all static25 plus both additions found FUSK to be the best static25 move:

| Move | Win probability | Gain over best static25 | Equity gain | Conservative per-comparison WP SEM upper bound |
| --- | ---: | ---: | ---: | ---: |
| FUSK |98.4594%| baseline | baseline | — |
| KiSTFUL |99.8313%|+1.3719pp|−16.4147|0.0490pp|
| FLOUT |99.4688%|+1.0095pp|+2.7008|0.0588pp|

The mean/p90/p99 immediate opponent reply-score diagnostics did not reveal a large direct threat-tail reduction. Spending the blank and playing more tiles are descriptive differences, not an established mechanism. This is a confirmed valuable admission example under the rollout model, not a population estimate.

''',f"Evidence: {link('new1217_all25_p16.csv')}, {link('new1217_all25.json')}, {link('threat_tail1217.json')}, {link('candidate_features.csv')}.\n\n",
'### Five additional fresh cases\n\nThese were selected after observing outside25 choices with primary gains≥1pp, excluding1217. Each gets a new300-second sixteen-ply round-robin sim against every static25 candidate, with an independent seed. Their values do not replace the primary estimate.\n\n']
rows=[['Position','Candidate (static rank)','Best static25','WP gain (pp)','WP SEM upper (pp)','Equity gain'],['---:','---','---','---:','---:','---:']]
for e in t['fresh_validations']:rows.append([e['pos'],f"{e['move']} ({e['rank']})",e['best_static25_move'],n(e['wp_gain_pp']),f"{e['wp_sem_upper_pp']:.3f}",n(e['equity_gain'])])
lines+=[table(rows),f"\nCompleted confirmations: {len(t['fresh_validations'])}/5. Details: {link('validation_cases.json')}, {link('secondary_summary.json')}.\n\n",
'''### Correction to the older examples

BE retains its benefit over GIBE at six and sixteen plies. CEP reverses against COPEN: the earlier small four-ply gain becomes about−1.25pp at six plies and−1.45pp at sixteen. CANOE still beats the old selected ENCINAL, but a600-second sixteen-ply evaluation over the entire static25 set finds NAP about1.44pp better than CANOE. A separate300-second seed again puts NAP above CANOE, CANAL andANAL. Thus CANOE-versus-ENCINAL alone does not establish a long-depth benefit beyond the entire static25 set.

''',f"Evidence: {link('horizons.json')}, {link('canoe_all25.json')}, {link('alternatives941_p16.csv')}.\n",
'## Full-budget adaptive-width comparison\n\n',
f"Same preselected96 nonopening+32 opening secondary positions; {s['completed_width_with_reference']}/128 currently joined. All distinct selections use full15 seconds with probability cutoff disabled. Baseline is static25_fulltime. Adaptive_static takes all static moves within15 points, minimum8, capped by120 available static moves. Adaptive_signals adds pure threat/setup top5 within25 points and exchange quota5 within35 points. Setup draws exclude the sampled opponent rack here. Static60 is the broad static control.\n\n"]
for group,g in s['width'].items():lines += [f'### {group}: {g["positions"]} positions\n\n',secondary_table(g,True),f"\nFulltime25 versus ordinary ceiling-budget25: WP {metric(g['fulltime_vs_ceiling_baseline'])}; equity {metric(g['fulltime_vs_ceiling_baseline'],'selected_equity_gain')}.\n\nAdaptive_signals versus static60, paired on the same positions: WP {metric(g['vs_static60']['adaptive_signals'])}; equity {metric(g['vs_static60']['adaptive_signals'],'selected_equity_gain')}.\n\n"]
lines+=['## Conditioned setup draws\n\n',f"{s['completed_conditioned_with_main_reference']}/128 preselected secondary positions joined. Remove each sampled opponent rack from the unseen pool before drawing the heuristic follow-up rack; actual engine rollouts are unchanged. These comparisons use the same independent primary reference.\n\n"]
rows=[['Stratum','Conditioned policy','Positions','Versus unconditioned: WP ± SE (pp)','Versus static25: WP ± SE (pp)'],['---','---','---:','---:','---:']]
for group,g in s['conditioned'].items():
 for arm,r in g['vs_unconditioned'].items():rows.append([group,arm,g['positions'],metric(r),metric(g['arms'][arm])])
lines += [table(rows),'\n']
lines+=['## Same-count static controls\n\n',f"{s['completed_matched_with_reference']}/128 secondary positions joined. Static prefixes have exactly the corresponding primary setup_wide or combined pool count. The static controls use full15 seconds, four plies; original heuristic selections retain their ceiling-budget protocol. Both are evaluated under the same independent reference.\n\n"]
for group,g in s['matched'].items():
 rows=[['Heuristic vs same-count static','Positions','WP gain ± SE (pp)','Equity gain ± SE'],['---','---:','---:','---:']]
 for arm,r in g['heuristic_vs_static_same_count'].items():rows.append([arm,g['positions'],metric(r),metric(r,'selected_equity_gain')])
 lines += [f'### {group}\n\n',table(rows)]
rows=[['Stratum','Static control','Fulltime25 joined','Control minus fulltime25: WP ± SE (pp)'],['---','---','---:','---:']]
for group,g in s['matched'].items():
 for arm,r in g['static_control_vs_fulltime25'].items():rows.append([group,arm,g['with_fulltime25_positions'],metric(r)])
lines += ['\n',table(rows)]
lines+=['\n## Rollout-depth comparison\n\n',f"{t['completed_depth']}/64 preselected positions have complete six-ply selections and a separate60-second six-ply reference. Compare four-ply and six-ply selected moves using that same six-ply reference, not values from different horizons.\n\n"]
for group,g in t['depth'].items():lines += [f'### Six-ply {group}: {g["positions"]} positions\n\n',secondary_table(g)]
rows=[['Stratum','Policy','Joined','Six-ply choice minus four-ply choice: WP ± SE (pp)'],['---','---','---:','---:']]
for group,g in t['four_vs_six'].items():
 for arm,r in g['six_minus_four'].items():rows.append([group,arm,g['positions'],metric(r,cluster=False)])
lines += ['\n',table(rows),'\n## Targeted15-second sixteen-ply admission tests\n\nStatic25 versus static25 plus the observed valuable addition, using new selection seeds. This tests exploitation once admitted and is not a fresh general candidate-generation policy. Independent long-depth reference values evaluate both selected moves.\n\n']
rows=[['Position','Static25 selection','Augmented selection','Outside25 selected?','Independent WP gain (pp)'],['---:','---','---','---','---:']]
for e in t['admission_tests']:rows.append([e['pos'],e['baseline_move'],e['admitted_selection'],e['admitted_selected_outside25'],n(e['paired']['selected_wp_gain_pp']['mean'])])
lines += [table(rows),'\n## Prospective tile-count/exchange quota\n\n',f"{t['completed_tile']}/40 new positions complete:32 game-derived positions from new no-PAT static games, one phase-balanced position per game, plus8 independently generated openings. Three of the game-derived positions are first turns: the actual board split is29 nonempty positions and11 empty boards. Preserve all observations and report that actual split below. The rule was devised after observing KiSTFUL: static25 plus the highest-static-equity placement for each tiles-played count1–7 within35 points; optional exchange quota5 within35 points. Full15-second four-ply selections, separate60-second reference.\n\n"]
for group in ['strict_nonopening','all_empty_boards']:
 g=t['tile'][group];title='Nonempty board' if group=='strict_nonopening' else 'Empty board';lines += [f'### {title}: {g["positions"]} positions\n\n',secondary_table(g)]
lines+=['\n### Fresh opening exchange discoveries\n\nThe prospective quota test discovers EI at static rank63 on empty-board position106 andO at static rank76 on position6007. Follow-ups evaluate the entire actually simulated augmented pool:32 candidates at106,31 at6007. Independent budgets are300 seconds at six plies and600 seconds at sixteen for106;300 seconds at sixteen for6007. The original selected exchange is tested separately from the best additional move found afterward in the reference; the latter is a diagnostic maximum. Fresh15-second deeper selections from the same sets are then evaluated under those independent references.\n\n']
rows=[['Position','Plies','Original exchange','Best static25','Gain (pp)','SEM upper (pp)','Best added diagnostic','Diagnostic gain (pp)'],['---:','---:','---','---','---:','---:','---','---:']]
for e in t['prospective_exchange_validation']:
 rows.append([e['pos'],e['plies'],e['original_exchange'],e['best_static25'],n(e['original_exchange_gain_pp']),f"{e['original_exchange_sem_upper_pp']:.3f}",e['best_added_diagnostic'],n(e['best_added_gain_pp'])])
lines += [table(rows),'\n']
rows=[['Position','Plies','Fresh15-second static25 selection','Augmented selection','Independent WP gain (pp)'],['---:','---:','---','---','---:']]
for e in t['prospective_exchange_validation']:
 timed=e.get('timed_selection')
 if timed:rows.append([e['pos'],e['plies'],timed['baseline_move'],timed['augmented_move'],n(timed['paired']['selected_wp_gain_pp']['mean'])])
lines += [table(rows),'\n']
lines+=['\n## Targeted exchange horizon checks\n\nThe three primary exchange-arm choices outside static25 had near-zero four-ply reference WP. Independently evaluate each against every static25 move for180 seconds at sixteen plies. Zero sampled WP and zero sample SEM do not prove a move cannot win. These are post-outcome checks, not population averages.\n\n']
rows=[['Position','Exchange (static rank)','Best static25','Exchange WP','Best static25 WP','Gain (pp)','Equity gain'],['---:','---','---','---:','---:','---:','---:']]
for e in t['exchange_validations']:rows.append([e['pos'],f"{e['move']} ({e['rank']})",e['best_static25_move'],f"{100*e['candidate_wp']:.5f}%",f"{100*e['best_static25_wp']:.5f}%",n(e['wp_gain_pp']),n(e['equity_gain'])])
lines += [table(rows),'\n']
lines+=['\n## Retrospective admission diagnostics\n\nThese are observed candidate-coverage maxima under the reference, not timed selected-move gains. Larger sets have more noisy maxima; do not treat this as an unbiased tuning comparison.\n\n']
rows=[['Pool rule','Mean nonopening candidates','Range','Observed coverage gain over static25 (pp)'],['---','---:','---','---:']]
for arm in ['static60','band10_min8','band15_min8','band20_min8','band25_min8','tiles1_margin35','tiles3_margin35','score1_margin35','exchange5_margin35']:
 r=c['groups']['nonopening'][arm];rows.append([arm,f"{r['candidate_count']['mean']:.2f}",r['candidate_range'],n(r['coverage_gain_pp']['mean'])])
lines += [table(rows),'''\nA tile-count quota of one adds only one move at1217 and captures KiSTFUL, but misses most other promising additions. A narrow15-point static band misses KiSTFUL, FLOUT, YETT andKLOOFS; a generous25-point band can grow to the120-candidate cap. Adaptive counts therefore need both admission coverage and timed-selection testing.

## Validity, repairs and reproducibility

- All root ranking and sim rollouts disable PAT. CSW24, four/six/sixteen plies as recorded, one sim thread per worker. Win-probability-only selection; no production policy integration, commits or pushes.
- Minimum30 iterations/play; ordinary selections can terminate at sampled WP0/1. Cutoff0 was initially mistaken for disabled. Seven short primary references were rerun for the intended60 seconds with cutoff−1, preserving originals. Primary analyses use those completed repairs. Fulltime width/depth/quota/matched/admission selections disable that cutoff explicitly.
- An expanded-pool PASS sentinel caused the research harness to abort. Exclude PASS; preserve210 complete main positions, archive original CSVs, remove only incomplete trailing positions, and resume. Preserve113 complete conditioned positions and recover the15 missing cases. Same candidate policy parameters remain in force.
- Main setup draws retain the original approximation that can include tiles already assigned to a sampled opponent rack. A separate conditioned study removes that rack. The heuristic also misextracts the leave of an exchange containing a blank because blank and played-through markers share the same value. Actual sim sampling and exported candidate leaves are correct; this remains a heuristic limitation, not silently changed during active comparisons.
- Threat/setup reply searches choose highest-score placements, while actual static rollouts choose by equity including leave value. This model mismatch could affect proxy rankings; no causal comparison of reply models was run.
- Candidate generation is restricted to the finite available pool. Static rank120 examples sit at the search boundary. Sixteen-ply greedy static rollouts are a sensitivity check, not an optimal full-game oracle.
- Independent reference estimates are noisy; per-example WP SEM bounds sum both marginal SEMs conservatively because paired covariance is unavailable. Primary table errors describe variation across sampled positions, with source-game clustering. Reference noise, rollout bias, multiple policies and post-outcome follow-ups limit population conclusions.
- The first structural-quota game-seed interval overlapped the primary games. Archive it in tile_followup_overlap_excluded and exclude all of its outcomes. Regenerate the32 games from a disjoint interval; zero exact CGP intersection is asserted for complete generated-game files. The originally preselected eight opening racks and the fixed quota rule are retained.
- Board occupancy is audited directly from CGPs. The primary split is256 nonempty+64 empty boards. The fresh quota sample includes29 nonempty+11 empty boards; three game-derived first turns are retained and labeled correctly, rather than silently resampled. Internal nonopening keys for the original quota stratum mean game-derived; explicit strict_nonopening/all_empty_boards keys provide the actual board split.
- Numbered worker files alone enter analysis; smoke tests, partial positions and incomplete reference repairs are excluded. The original primary sample and the prospective40-position sample are separate. Secondary subsets were chosen without their outcomes; targeted confirmations were chosen after observing primary gains.
- Timed sim results depend on machine load as well as seeds. Later CPU-capacity queues hold worker concurrency near the machine's ten CPUs. Initial targeted validations sometimes added a worker alongside the primary and conditioning runs, so this is not an isolated single-core throughput benchmark. Immutable binaries are never overwritten while active. Keep the recorded wall times and iteration counts, not just advertised budgets.

''',f"Full methods: {link('README.md')}. Primary data/analysis: {link('summary.json')}, {link('summarize.py')}, {link('positions.cgp')}, {link('positions.meta.csv')}, {link('manifest.json')}. Secondary analysis: {link('secondary_summary.json')}, {link('secondary_summary.py')}, {link('coverage_summary.json')}, {link('budget_audit.json')}. All full worker CSVs, manifests, logs and immutable binaries are alongside this report.\n"]
body=''.join(lines)
for old,new in {'at15':'at 15','fresh15':'fresh 15','of−':'of −','for180':'for 180','at1217':'at 1217','Minimum30':'Minimum 30','intended60':'intended 60','the32':'the 32','is256':'is 256','includes29':'includes 29','averages30':'averages 30','chooses10':'chooses 10','across256':'across 256','On96':'On 96','averages39':'averages 39','to8':'to 8','to125':'to 125','gains1':'gains 1','a15':'a 15','setup+':'setup +','combined+':'combined +','on96':'on 96','fresh40':'fresh 40','bag7':'bag 7','exEI':'EI','andO':'and O','rank63':'rank 63','rank76':'rank 76','position106':'position 106','position6007':'position 6007','at106':'at 106','at6007':'at 6007','for106':'for 106','for6007':'for 6007','window:19':'window: 19','59UTC,2026':'59 UTC, 2026','andFLOUT':'and FLOUT','from128':'from 128','use64':'use 64','the15':'the 15','to15':'to 15','minimum30':'minimum 30','separate60':'separate 60','top120':'top 120','to5':'to 5','within35':'within 35','top25':'top 25','weight0.5':'weight 0.5','top5':'top 5','within25':'within 25','outside25':'outside 25','not95':'not 95','bootstrap95':'bootstrap 95','Bootstrap95':'Bootstrap 95','bag≥60':'bag ≥ 60','middle30':'middle 30','late7':'late 7','between1':'between 1','and99':'and 99','position1217':'position 1217','bag8':'bag 8','retainsLOT':'retains LOT','leavesO':'leaves O','rank49,24':'rank 49, 24','rank89,27':'rank 89, 27','independent600':'independent 600','gains≥1pp':'gains ≥ 1 pp','excluding1217':'excluding 1217','new300':'new 300','about−1':'about −1','a600':'a 600','about1':'about 1','separate300':'separate 300','andANAL':'and ANAL','preselected96':'preselected 96','+32':' + 32','full15':'full 15','within15':'within 15','minimum8':'minimum 8','by120':'by 120','quota5':'quota 5','sixteen-ply admission':'sixteen-ply admission','four-ply selections':'four-ply selections','preselected positions':'preselected positions','positions complete:32':'positions complete: 32','plus8':'plus 8','after observing KiSTFUL':'after observing KiSTFUL','count1':'count 1','point15':'point 15','narrow15':'narrow 15','andKLOOFS':'and KLOOFS','generous25':'generous 25','the120':'the 120','retainLOT':'retain LOT','iterations/play; ordinary':'iterations/play; ordinary','WP0/1':'WP 0/1','Cutoff0':'Cutoff 0','cutoff−1':'cutoff −1','preserve210':'preserve 210','Preserve113':'Preserve 113','the15 missing':'the 15 missing','rank120':'rank 120','prospective40':'prospective 40','|98':'| 98','|99':'| 99','1.3719pp':'1.3719 pp','1.0095pp':'1.0095 pp','0.0490pp':'0.0490 pp','0.0588pp':'0.0588 pp'}.items():body=body.replace(old,new)
body=re.sub(r'([0-9])±',r'\1 ± ',body)
body=re.sub(r'(?<=[0-9])pp\b',' pp',body)
body='\n'.join('| '+' | '.join(cell.strip() for cell in line.split('|')[1:-1])+' |' if line.startswith('|') and line.endswith('|') else line for line in body.split('\n'))
body=re.sub(r'(?<!\n)\n(#{1,3} )',r'\n\n\1',body)
body=re.sub(r'(#{1,3} [^\n]+)\n(?!\n)',r'\1\n\n',body)
(D/'REPORT.md').write_text(body);print('Wrote',D/'REPORT.md')
