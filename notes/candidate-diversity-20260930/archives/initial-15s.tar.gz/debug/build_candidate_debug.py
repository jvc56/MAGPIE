#!/usr/bin/env python3
"""Build an offline candidate-pool explorer from the saved research CSVs."""
import csv
import json
import re
from collections import Counter
from pathlib import Path

SOURCE = Path('/Users/olaugh/sources/magpie-pat-postx/postx/threatgames/extended_2h40')
OUTPUT = Path(__file__).parent / 'candidate-pools-debug.html'

def rows(path):
    return list(csv.DictReader(path.open()))

def board(cgp):
    result = []
    for encoded in cgp.split()[0].split('/'):
        line = []
        for token in re.findall(r'\d+|.', encoded):
            line.extend([''] * int(token) if token.isdigit() else [token])
        assert len(line) == 15
        result.append(line)
    assert len(result) == 15
    return result

def dataset(directory, name, files, position_files, arms):
    positions = {}
    metadata = {int(row['pos']): row for row in rows(directory / 'positions.meta.csv')}
    for filename in position_files:
        for line in (directory / filename).read_text().splitlines():
            identifier, cgp = line.split(',', 1)
            identifier = int(identifier)
            fields = cgp.split()
            positions[identifier] = dict(id=identifier, cgp=cgp, board=board(cgp), racks=fields[1].split('/'), scores=list(map(int, fields[2].split('/'))), onturn=0, scoreless=int(fields[3]), meta=metadata.get(identifier, {}), candidates={}, pools={})
    for row in rows(directory / 'candidate_features.csv'):
        position = positions[int(row['pos'])]
        position['candidates'][row['move']] = dict(move=row['move'], index=int(row['pool_index']), rank=int(row['global_static_rank']), score=float(row['score']), eq=float(row['static_eq']), leave=row['leave'], tiles=int(row['tiles_played']), type=int(row['type']), results={})
    records = {}
    for filename in files:
        for row in rows(directory / filename):
            records[int(row['pos']), row['arm'], row['move']] = row
    if (directory / 'r0.csv').exists():
        for row in rows(directory / 'r0.csv'):
            records[int(row['pos']), row['arm'], row['move']] = row
    for (identifier, arm, move), row in records.items():
        if arm not in arms + ['reference']:
            continue
        position = positions[identifier]
        candidate = position['candidates'][move]
        candidate['threat'] = float(row['threat_value'])
        candidate['setup'] = float(row['setup_value'])
        candidate['results'][arm] = [float(row[key]) for key in ['sim_wp', 'sim_wp_sem', 'sim_eq', 'sim_eq_sem']] + [int(row['chosen'])]
        position['pools'][arm] = dict(count=int(row['candidates']), seconds=round(float(row['wall_ms']) / 1000, 2))
        position['bag'] = int(row['bag'])
    # Supplementary deeper references are kept separate from the main reference.
    for identifier, position in positions.items():
        deepfile = directory / (f'new{identifier}_all25_p16.csv' if name == 'primary' else f'validate{identifier}_p16.csv')
        if deepfile.exists():
            for row in rows(deepfile):
                if row['move'] in position['candidates']:
                    candidate = position['candidates'][row['move']]
                    candidate['results']['deep16'] = [float(row[key]) for key in ['sim_wp', 'sim_wp_sem', 'sim_eq', 'sim_eq_sem']] + [int(row['chosen'])]
                    position['pools']['deep16'] = dict(count=int(row['candidates']), seconds=round(float(row['wall_ms']) / 1000, 2))
        base = arms[0]
        raw_sources = {}
        if name == 'primary':
            eligible = [candidate for candidate in position['candidates'].values() if candidate['eq'] >= max(item['eq'] for item in position['candidates'].values()) - 25]
            for component in ['threat', 'setup']:
                full_ranking = sorted(eligible, key=lambda candidate: (-(candidate[component] - candidate['eq']), candidate['index']))
                ranked = full_ranking[:5]
                for candidate in ranked:
                    raw_sources.setdefault(candidate['move'], []).append('signals_' + component)
                if len(full_ranking) > 5 and abs((full_ranking[4][component] - full_ranking[4]['eq']) - (full_ranking[5][component] - full_ranking[5]['eq'])) < 0.000003:
                    raw_sources['ambiguous_boundary'] = []
            # Ensure the reconstruction from exported values exactly reproduces
            # the recorded union before exposing the finer provenance labels.
            recorded = {candidate['move'] for candidate in position['candidates'].values() if 'signals' in candidate['results'] and base not in candidate['results']}
            reconstructed = {move for move in raw_sources if move in position['candidates'] and base not in position['candidates'][move]['results']}
            if recorded != reconstructed or 'ambiguous_boundary' in raw_sources:
                # Rounded CSV scores can hide tie order. Keep the recorded
                # mixed-source provenance rather than assert a finer source.
                raw_sources = {}
        for candidate in position['candidates'].values():
            candidate['sources'] = [] if base in candidate['results'] else [arm for arm in arms[1:] if arm not in ['combined', 'tile_exchange'] and arm in candidate['results']]
            if 'signals' in candidate['sources'] and raw_sources:
                candidate['sources'].remove('signals')
                candidate['sources'].extend(raw_sources[candidate['move']])
            if name == 'quota' and base not in candidate['results'] and 'tile_exchange' in candidate['results'] and 'tile_quota' not in candidate['results']:
                candidate['sources'].append('exchange')
            # Check all placements against the board, including played-through tiles.
            if candidate['type'] == 1:
                coordinate, word = candidate['move'].split()
                vertical = coordinate[0].isalpha()
                column = ord(re.search('[a-o]', coordinate).group()) - ord('a')
                rowindex = int(re.search(r'\d+', coordinate).group()) - 1
                added = 0
                for offset, letter in enumerate(word):
                    row = rowindex + (offset if vertical else 0)
                    col = column + (0 if vertical else offset)
                    assert 0 <= row < 15 and 0 <= col < 15, candidate['move']
                    existing = position['board'][row][col]
                    assert not existing or existing == letter, (identifier, candidate['move'], existing, letter)
                    added += not bool(existing)
                assert added == candidate['tiles'], (identifier, candidate['move'], added, candidate['tiles'])
        for arm in arms + ['reference']:
            assert sum(arm in candidate['results'] for candidate in position['candidates'].values()) == position['pools'][arm]['count']
            assert sum(candidate['results'].get(arm, [0]*5)[4] for candidate in position['candidates'].values()) == 1
        distribution = Counter({row[0]: int(row[2]) for row in csv.reader((SOURCE.parents[2] / 'data/letterdistributions/english.csv').open())})
        for line in position['board']:
            for letter in line:
                if letter:
                    distribution['?' if letter.islower() else letter] -= 1
        distribution.subtract(position['racks'][position['onturn']])
        assert all(count >= 0 for count in distribution.values())
        assert sum(distribution.values()) == position['bag'] + len(position['racks'][1-position['onturn']])
        position['unseen'] = dict(distribution)
        position['candidates'] = sorted(position['candidates'].values(), key=lambda candidate: candidate['rank'])
    return dict(name=name, arms=arms, positions=list(positions.values()))

data = dict(datasets=[
    dataset(SOURCE, 'primary', [f'w{index}.csv' for index in range(8)], ['positions.cgp', 'openings.cgp'], ['static25', 'threat_wide', 'setup_wide', 'signals', 'exchange', 'combined']),
    dataset(SOURCE / 'tile_followup', 'quota', ['w0.csv', 'w1.csv'], ['positions.cgp'], ['static25_fulltime', 'tile_quota', 'tile_exchange']),
], premiums=[list(line) for line in (SOURCE.parents[2] / 'data/layouts/standard15.txt').read_text().splitlines()[1:]], tileScores={row[0]: int(row[3]) for row in csv.reader((SOURCE.parents[2] / 'data/letterdistributions/english.csv').open())})
assert len(data['premiums']) == 15 and all(len(row) == 15 for row in data['premiums'])
template = (Path(__file__).parent / 'candidate_debug_template.html').read_text()
OUTPUT.write_text(template.replace('/*DATA*/null', json.dumps(data, separators=(',', ':'))))
print(f'Built {OUTPUT} ({OUTPUT.stat().st_size:,} bytes); verified 360 positions, all pool counts, choices, and tile overlays.')
