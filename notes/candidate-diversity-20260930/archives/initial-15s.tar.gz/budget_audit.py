import csv,json,sys
from pathlib import Path
D=Path(sys.argv[1]);out={}
for label,files in [('main',D.glob('w[0-7].csv')),('conditioned',D.glob('c[01].csv')),('width',D.glob('v[01].csv')),('depth',D.glob('d[0-3].csv')),('matched',D.glob('m[0-3].csv')),('tile', (D/'tile_followup').glob('w[01].csv'))]:
 groups={}
 for f in files:
  for r in csv.DictReader(f.open()):
   if None in r or r.get('wall_ms') in (None,''):continue
   groups.setdefault((r['pos'],r['arm']),[]).append(r)
 arms={}
 for (p,a),rr in groups.items():
  if len(rr)!=int(rr[0]['candidates']):continue
  m=float(rr[0]['wall_ms']);x=arms.setdefault(a,{'positions':0,'reused':0,'short':0,'full':0,'min_nonreuse_ms':None,'max_ms':0,'iterations':[],'candidate_cap120':0});x['positions']+=1;x['max_ms']=max(x['max_ms'],m);x['candidate_cap120']+=int(rr[0]['candidates'])>=120
  if m<1:x['reused']+=1
  else:
   x['min_nonreuse_ms']=m if x['min_nonreuse_ms'] is None else min(x['min_nonreuse_ms'],m);x['iterations'].append(int(rr[0]['iterations']));x['full' if m>=(59000 if a=='reference' else 14900) else 'short']+=1
 for x in arms.values():
  n=x.pop('iterations');x['mean_iterations']=sum(n)/len(n) if n else None;x['min_iterations']=min(n) if n else None
 out[label]=arms
(D/'budget_audit.json').write_text(json.dumps(out,indent=2)+'\n');print({k:{a:(v['positions'],v['short'],v['full'],v['reused']) for a,v in aa.items()} for k,aa in out.items()})
